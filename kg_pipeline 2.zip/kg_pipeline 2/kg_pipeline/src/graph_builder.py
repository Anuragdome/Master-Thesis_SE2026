"""
src/graph_builder.py
====================
Stage 4: Knowledge Graph Construction

Takes resolved triples and builds a knowledge graph.

Two backends:
  - NetworkX: always available, great for analysis and visualisation
  - Neo4j: production graph database with Cypher querying

Exports to JSON and CSV regardless of which backend is used.
"""

import json
import logging
import csv
from pathlib import Path
from typing import List, Dict, Any, Optional
from collections import defaultdict

from src.extraction import Triple
from src.resolution import EntityResolver

logger = logging.getLogger(__name__)


class GraphBuilder:
    """
    Constructs a knowledge graph from resolved triples.

    Always builds a NetworkX in-memory graph for analysis.
    Optionally persists to Neo4j for production querying.
    """

    def __init__(
        self,
        neo4j_enabled: bool = True,
        neo4j_uri: str = "bolt://localhost:7687",
        neo4j_user: str = "neo4j",
        neo4j_password: str = "password",
        output_dir: Path = Path("data/output"),
    ):
        self.neo4j_enabled = neo4j_enabled
        self.neo4j_uri = neo4j_uri
        self.neo4j_user = neo4j_user
        self.neo4j_password = neo4j_password
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self._nx_graph = None
        self._neo4j_driver = None

    # ── Public API ────────────────────────────────────────────────────────

    def build(
        self, triples: List[Triple], resolver: Optional[EntityResolver] = None
    ) -> Dict[str, Any]:
        """
        Main entry point. Builds graph from triples.
        Returns a stats dict.
        """
        import networkx as nx
        self._nx_graph = nx.MultiDiGraph()

        logger.info(f"Building graph from {len(triples)} triple(s)...")

        # Add nodes
        if resolver:
            for entity in resolver.get_entity_summary():
                self._nx_graph.add_node(
                    entity["name"],
                    type=entity["type"],
                    aliases=entity["aliases"],
                )

        # Add edges
        for t in triples:
            self._nx_graph.add_node(t.subject, type=t.subject_type)
            self._nx_graph.add_node(t.object, type=t.object_type)
            self._nx_graph.add_edge(
                t.subject,
                t.object,
                relation=t.relation,
                confidence=t.confidence,
                source=t.source_file,
            )

        stats = self._graph_stats()
        logger.info(f"  Nodes: {stats['nodes']}, Edges: {stats['edges']}")

        # Export to JSON and CSV
        self._export_json(triples)
        self._export_csv(triples)
        self._export_cypher(triples)

        # Write to Neo4j if enabled
        if self.neo4j_enabled:
            self._write_to_neo4j(triples, resolver)

        return stats

    def get_networkx_graph(self):
        """Return the in-memory NetworkX graph."""
        return self._nx_graph

    def query_neighbours(self, entity_name: str, depth: int = 1) -> List[Triple]:
        """Return all triples connected to an entity up to a given depth."""
        if self._nx_graph is None:
            return []

        import networkx as nx
        results = []
        try:
            ego = nx.ego_graph(self._nx_graph, entity_name, radius=depth)
            for u, v, data in ego.edges(data=True):
                results.append(Triple(
                    subject=u,
                    subject_type=self._nx_graph.nodes[u].get("type", "CONCEPT"),
                    relation=data.get("relation", "related_to"),
                    object=v,
                    object_type=self._nx_graph.nodes[v].get("type", "CONCEPT"),
                    confidence=data.get("confidence", 1.0),
                ))
        except Exception as e:
            logger.warning(f"Could not query neighbours for '{entity_name}': {e}")
        return results

    # ── Neo4j ─────────────────────────────────────────────────────────────

    def _get_neo4j_driver(self):
        if self._neo4j_driver is not None:
            return self._neo4j_driver
        try:
            from neo4j import GraphDatabase
            self._neo4j_driver = GraphDatabase.driver(
                self.neo4j_uri,
                auth=(self.neo4j_user, self.neo4j_password),
            )
            self._neo4j_driver.verify_connectivity()
            logger.info("  Connected to Neo4j")
            return self._neo4j_driver
        except Exception as e:
            logger.warning(f"  Neo4j connection failed: {e}")
            logger.warning("  Skipping Neo4j — results saved to files only")
            self.neo4j_enabled = False
            return None

    def _write_to_neo4j(
        self, triples: List[Triple], resolver: Optional[EntityResolver]
    ) -> None:
        logger.info("Writing graph to Neo4j...")
        driver = self._get_neo4j_driver()
        if driver is None:
            return

        with driver.session() as session:
            # Clear existing data (for a clean run)
            session.run("MATCH (n) DETACH DELETE n")

            # Create entity nodes
            if resolver:
                for entity in resolver.get_entity_summary():
                    session.run(
                        """
                        MERGE (e:Entity {name: $name})
                        SET e.type = $type, e.aliases = $aliases
                        """,
                        name=entity["name"],
                        type=entity["type"],
                        aliases=list(entity["aliases"]),
                    )

            # Create triples as edges
            for t in triples:
                cypher = f"""
                MERGE (s:Entity {{name: $subject}})
                ON CREATE SET s.type = $subject_type
                MERGE (o:Entity {{name: $object}})
                ON CREATE SET o.type = $object_type
                MERGE (s)-[r:`{t.relation.upper()}`]->(o)
                SET r.confidence = $confidence, r.source = $source
                """
                session.run(
                    cypher,
                    subject=t.subject,
                    subject_type=t.subject_type,
                    object=t.object,
                    object_type=t.object_type,
                    confidence=t.confidence,
                    source=t.source_file,
                )

        logger.info("  Neo4j write complete")
        logger.info("  Open http://localhost:7474 to explore the graph")

    # ── Exports ───────────────────────────────────────────────────────────

    def _export_json(self, triples: List[Triple]) -> None:
        out = self.output_dir / "triples.json"
        data = [t.to_dict() for t in triples]
        out.write_text(json.dumps(data, indent=2, ensure_ascii=False))
        logger.info(f"  Saved {len(data)} triples → {out}")

    def _export_csv(self, triples: List[Triple]) -> None:
        out = self.output_dir / "triples.csv"
        with open(out, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f, fieldnames=["subject", "subject_type", "relation", "object", "object_type", "confidence", "source_chunk_id", "source_file"]
            )
            writer.writeheader()
            for t in triples:
                writer.writerow(t.to_dict())
        logger.info(f"  Saved CSV → {out}")

    def _export_cypher(self, triples: List[Triple]) -> None:
        """Export a .cypher file you can paste into Neo4j Browser."""
        out = self.output_dir / "import_graph.cypher"
        lines = ["// Auto-generated Cypher — paste into Neo4j Browser\n"]
        lines.append("MATCH (n) DETACH DELETE n;\n")
        for t in triples:
            rel = t.relation.upper().replace("-", "_")
            line = (
                f'MERGE (s:Entity {{name: "{t.subject}", type: "{t.subject_type}"}}) '
                f'MERGE (o:Entity {{name: "{t.object}", type: "{t.object_type}"}}) '
                f'MERGE (s)-[:`{rel}` {{confidence: {t.confidence:.2f}}}]->(o);'
            )
            lines.append(line)
        out.write_text("\n".join(lines))
        logger.info(f"  Saved Cypher script → {out}")

    # ── Stats ──────────────────────────────────────────────────────────────

    def _graph_stats(self) -> Dict[str, Any]:
        g = self._nx_graph
        if g is None:
            return {}

        n = g.number_of_nodes()
        e = g.number_of_edges()
        density = (e / (n * (n - 1))) if n > 1 else 0

        # Entity type distribution
        type_counts: Dict[str, int] = defaultdict(int)
        for _, data in g.nodes(data=True):
            type_counts[data.get("type", "UNKNOWN")] += 1

        # Relation type distribution
        rel_counts: Dict[str, int] = defaultdict(int)
        for _, _, data in g.edges(data=True):
            rel_counts[data.get("relation", "unknown")] += 1

        return {
            "nodes": n,
            "edges": e,
            "density": round(density, 4),
            "entity_types": dict(type_counts),
            "relation_types": dict(rel_counts),
        }
