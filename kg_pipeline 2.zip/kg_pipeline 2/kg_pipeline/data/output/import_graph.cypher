// Auto-generated Cypher � paste into Neo4j Browser

MATCH (n) DETACH DELETE n;

MERGE (s:Entity {name: "GreenTech Solutions", type: "ORGANIZATION"}) MERGE (o:Entity {name: "SolarPower Inc.", type: "ORGANIZATION"}) MERGE (s)-[:`PARTNERED_WITH` {confidence: 0.99}]->(o);
MERGE (s:Entity {name: "GreenTech Solutions", type: "ORGANIZATION"}) MERGE (o:Entity {name: "2025", type: "DATE"}) MERGE (s)-[:`PARTNERED_IN` {confidence: 0.98}]->(o);
MERGE (s:Entity {name: "SolarPower Inc.", type: "ORGANIZATION"}) MERGE (o:Entity {name: "2025", type: "DATE"}) MERGE (s)-[:`PARTNERED_IN` {confidence: 0.98}]->(o);
MERGE (s:Entity {name: "GreenTech Solutions", type: "ORGANIZATION"}) MERGE (o:Entity {name: "renewable energy infrastructure", type: "TECHNOLOGY"}) MERGE (s)-[:`IS_BUILDING` {confidence: 0.97}]->(o);
MERGE (s:Entity {name: "SolarPower Inc.", type: "ORGANIZATION"}) MERGE (o:Entity {name: "renewable energy infrastructure", type: "TECHNOLOGY"}) MERGE (s)-[:`IS_BUILDING` {confidence: 0.97}]->(o);
MERGE (s:Entity {name: "renewable energy infrastructure", type: "TECHNOLOGY"}) MERGE (o:Entity {name: "Berlin", type: "LOCATION"}) MERGE (s)-[:`LOCATED_IN` {confidence: 0.98}]->(o);
MERGE (s:Entity {name: "Renewable Energy Network", type: "EVENT"}) MERGE (o:Entity {name: "European Union", type: "ORGANIZATION"}) MERGE (s)-[:`FUNDED_BY` {confidence: 0.99}]->(o);
MERGE (s:Entity {name: "Renewable Energy Network", type: "EVENT"}) MERGE (o:Entity {name: "Dr. Emma Carter", type: "PERSON"}) MERGE (s)-[:`MANAGED_BY` {confidence: 0.99}]->(o);
MERGE (s:Entity {name: "Solar panels", type: "PRODUCT"}) MERGE (o:Entity {name: "SolarPower Inc.", type: "ORGANIZATION"}) MERGE (s)-[:`SUPPLIED_BY` {confidence: 0.99}]->(o);
MERGE (s:Entity {name: "Solar panels", type: "PRODUCT"}) MERGE (o:Entity {name: "electricity", type: "CONCEPT"}) MERGE (s)-[:`GENERATE` {confidence: 0.98}]->(o);
MERGE (s:Entity {name: "electricity", type: "CONCEPT"}) MERGE (o:Entity {name: "battery systems", type: "TECHNOLOGY"}) MERGE (s)-[:`STORED_IN` {confidence: 0.98}]->(o);
MERGE (s:Entity {name: "battery systems", type: "TECHNOLOGY"}) MERGE (o:Entity {name: "EnergyTech Labs", type: "ORGANIZATION"}) MERGE (s)-[:`DEVELOPED_BY` {confidence: 0.99}]->(o);
MERGE (s:Entity {name: "Data", type: "CONCEPT"}) MERGE (o:Entity {name: "renewable energy infrastructure", type: "TECHNOLOGY"}) MERGE (s)-[:`FROM` {confidence: 0.95}]->(o);
MERGE (s:Entity {name: "Data", type: "CONCEPT"}) MERGE (o:Entity {name: "cloud platform", type: "TECHNOLOGY"}) MERGE (s)-[:`ANALYZED_USING` {confidence: 0.98}]->(o);
MERGE (s:Entity {name: "cloud platform", type: "TECHNOLOGY"}) MERGE (o:Entity {name: "Microsoft", type: "ORGANIZATION"}) MERGE (s)-[:`PROVIDED_BY` {confidence: 0.99}]->(o);
MERGE (s:Entity {name: "report", type: "CONCEPT"}) MERGE (o:Entity {name: "Technical University of Berlin", type: "ORGANIZATION"}) MERGE (s)-[:`PUBLISHED_BY` {confidence: 0.99}]->(o);
MERGE (s:Entity {name: "Renewable Energy Network", type: "EVENT"}) MERGE (o:Entity {name: "carbon emissions", type: "CONCEPT"}) MERGE (s)-[:`REDUCED` {confidence: 0.98}]->(o);
MERGE (s:Entity {name: "carbon emissions", type: "CONCEPT"}) MERGE (o:Entity {name: "15%", type: "CONCEPT"}) MERGE (s)-[:`REDUCED_BY` {confidence: 0.97}]->(o);
MERGE (s:Entity {name: "Renewable Energy Network", type: "EVENT"}) MERGE (o:Entity {name: "first year", type: "DATE"}) MERGE (s)-[:`OPERATED_FOR` {confidence: 0.95}]->(o);