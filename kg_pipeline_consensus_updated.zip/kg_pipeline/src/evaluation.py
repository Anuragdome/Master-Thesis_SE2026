"""
src/evaluation.py
=================
Stage 5: Knowledge Graph Evaluation

Computes metrics that go into your thesis:
  - Graph structure statistics (nodes, edges, density)
  - Entity type distribution
  - Relation diversity
  - Extraction coverage per document
  - Precision & recall against a gold standard, exact-match AND fuzzy-match
    (if provided) — this is the main "how accurate is the KG?" metric
  - Per-chunk extraction success rate
  - Hallucination / grounding report from Stage 2.5 (src/verification.py) —
    what fraction of triples are actually supported by the source text
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from collections import defaultdict, Counter

from rapidfuzz import fuzz

from src.extraction import Triple
from src.resolution import EntityResolver

logger = logging.getLogger(__name__)


class Evaluator:
    """
    Computes evaluation metrics for the knowledge graph pipeline.
    Generates a human-readable report saved to data/output/.
    """

    def __init__(
        self,
        output_dir: Path = Path("data/output"),
        gold_standard_path: Optional[Path] = None,
        fuzzy_match: bool = True,
        fuzzy_threshold: float = 85.0,
    ):
        self.output_dir = Path(output_dir)
        self.gold_standard_path = gold_standard_path
        self.fuzzy_match = fuzzy_match
        self.fuzzy_threshold = fuzzy_threshold

    def evaluate(
        self,
        raw_triples: List[Triple],
        resolved_triples: List[Triple],
        resolver: EntityResolver,
        graph_stats: Dict[str, Any],
        verification_stats: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Run all evaluations and return a results dict.
        Also writes a text report to data/output/evaluation_report.txt.
        """
        results: Dict[str, Any] = {}

        results["graph"] = graph_stats
        results["extraction"] = self._extraction_stats(raw_triples, resolved_triples)
        results["entity_coverage"] = self._entity_coverage(resolved_triples)
        results["relation_analysis"] = self._relation_analysis(resolved_triples)
        results["resolution"] = self._resolution_stats(resolver)
        results["hallucination_check"] = self._hallucination_stats(
            resolved_triples, verification_stats
        )

        if self.gold_standard_path and Path(self.gold_standard_path).exists():
            results["gold_standard"] = self._gold_standard_eval(resolved_triples)
        else:
            results["gold_standard"] = {
                "note": "No gold standard provided. Add a gold_standard.txt file to enable precision/recall."
            }

        self._write_report(results)
        self._write_json(results)
        return results

    # ── Evaluation sections ───────────────────────────────────────────────

    def _extraction_stats(
        self, raw: List[Triple], resolved: List[Triple]
    ) -> Dict[str, Any]:
        sources = defaultdict(int)
        for t in raw:
            sources[t.source_file] += 1

        return {
            "total_raw_triples": len(raw),
            "total_resolved_triples": len(resolved),
            "unique_relations": len({t.relation for t in resolved}),
            "triples_per_document": dict(sources),
            "avg_triples_per_chunk": round(
                len(raw) / max(len({t.source_chunk_id for t in raw}), 1), 2
            ),
        }

    def _entity_coverage(self, triples: List[Triple]) -> Dict[str, Any]:
        subjects = {t.subject for t in triples}
        objects = {t.object for t in triples}
        all_entities = subjects | objects

        type_counts: Dict[str, int] = defaultdict(int)
        for t in triples:
            type_counts[t.subject_type] += 1
            type_counts[t.object_type] += 1

        return {
            "unique_entities": len(all_entities),
            "entities_as_subject_only": len(subjects - objects),
            "entities_as_object_only": len(objects - subjects),
            "entities_in_both_roles": len(subjects & objects),
            "entity_type_distribution": dict(type_counts),
        }

    def _relation_analysis(self, triples: List[Triple]) -> Dict[str, Any]:
        relation_counts = Counter(t.relation for t in triples)
        avg_confidence = (
            sum(t.confidence for t in triples) / len(triples)
            if triples else 0
        )
        low_confidence = [
            str(t) for t in triples if t.confidence < 0.7
        ]

        return {
            "unique_relation_types": len(relation_counts),
            "most_common_relations": relation_counts.most_common(10),
            "average_confidence": round(avg_confidence, 3),
            "low_confidence_triples_count": len(low_confidence),
            "low_confidence_examples": low_confidence[:5],
        }

    def _resolution_stats(self, resolver: EntityResolver) -> Dict[str, Any]:
        total_names = len(resolver.canonical_map)
        canonical_count = len(set(resolver.canonical_map.values()))
        merged = total_names - canonical_count

        alias_sizes = [
            len(aliases)
            for aliases in resolver.aliases.values()
            if len(aliases) > 1
        ]

        return {
            "total_entity_strings_before_resolution": total_names,
            "canonical_entities_after_resolution": canonical_count,
            "aliases_merged": merged,
            "largest_alias_group_size": max(alias_sizes, default=0),
            "avg_aliases_per_merged_entity": (
                round(sum(alias_sizes) / len(alias_sizes), 2) if alias_sizes else 0
            ),
        }

    def _hallucination_stats(
        self,
        triples: List[Triple],
        verification_stats: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Summarises how many of the final triples are actually grounded in
        their source text, using the grounding_score/verified fields set
        by src/verification.py::HallucinationFilter (Stage 2.5).

        This is the KG-accuracy metric that doesn't require a hand-labelled
        gold standard: it's a direct check of "is this fact actually in the
        document?" rather than "does this fact match a reference list?".
        """
        checked = [t for t in triples if t.verified is not None]

        if not checked:
            return {
                "note": (
                    "No grounding data on the final triples (Stage 2.5 hallucination "
                    "filtering did not run, or these triples were loaded from an older "
                    "run). Enable it in config/settings.py to populate this section."
                )
            }

        verified = [t for t in checked if t.verified]
        unverified = [t for t in checked if not t.verified]
        avg_grounding = sum(t.grounding_score or 0 for t in checked) / len(checked)
        llm_checked = sum(1 for t in checked if t.verification_method == "llm")

        result = {
            "triples_checked": len(checked),
            "verified_triples": len(verified),
            "unverified_triples": len(unverified),
            "estimated_hallucination_rate": round(len(unverified) / len(checked), 4),
            "average_grounding_score": round(avg_grounding, 2),
            "llm_verification_calls": llm_checked,
            "unverified_examples": [str(t) for t in unverified[:5]],
        }
        if verification_stats:
            result["filter_run_summary"] = verification_stats
        return result

    def _gold_standard_eval(
        self, resolved_triples: List[Triple]
    ) -> Dict[str, Any]:
        """
        Compute precision and recall against a gold standard file.
        Gold standard format (one line per triple):
            Marie Curie | won | Nobel Prize in Physics

        Reports BOTH:
          - exact match: subject/relation/object must be identical after
            lower-casing. Strict, but under-counts correct facts that are
            just phrased slightly differently ("Nobel Prize in Physics" vs
            "the Nobel Prize for Physics").
          - fuzzy match (if enabled): a predicted triple counts as a match
            if its subject/relation/object are each within
            GOLD_STANDARD_FUZZY_THRESHOLD (rapidfuzz token_sort_ratio) of a
            gold triple. This is generally the more representative accuracy
            number for LLM-extracted KGs, and the one worth leading with in
            the thesis.
        """
        gold: List[Tuple[str, str, str]] = []
        with open(self.gold_standard_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = [p.strip() for p in line.split("|")]
                if len(parts) == 3:
                    gold.append((parts[0].lower(), parts[1].lower(), parts[2].lower()))

        predicted = {
            (t.subject.lower(), t.relation.lower(), t.object.lower())
            for t in resolved_triples
        }
        gold_set = set(gold)

        exact = self._precision_recall_f1(
            tp=len(predicted & gold_set),
            n_predicted=len(predicted),
            n_gold=len(gold_set),
        )
        result: Dict[str, Any] = {
            "gold_triples": len(gold_set),
            "predicted_triples": len(predicted),
            "exact_match": {**exact, "true_positives": len(predicted & gold_set)},
        }

        if self.fuzzy_match:
            fuzzy_tp, matched_pairs = self._fuzzy_match_count(predicted, gold_set)
            fuzzy = self._precision_recall_f1(
                tp=fuzzy_tp, n_predicted=len(predicted), n_gold=len(gold_set)
            )
            result["fuzzy_match"] = {
                **fuzzy,
                "true_positives": fuzzy_tp,
                "threshold": self.fuzzy_threshold,
            }
            result["fuzzy_match_examples"] = [
                f"{p} ~= {g}" for p, g in matched_pairs[:5]
            ]

        # Convenience top-level fields (fuzzy if available, else exact) so
        # existing code/notebooks reading precision/recall/f1_score directly
        # keep working.
        headline = result.get("fuzzy_match", result["exact_match"])
        result["precision"] = headline["precision"]
        result["recall"] = headline["recall"]
        result["f1_score"] = headline["f1_score"]

        return result

    @staticmethod
    def _precision_recall_f1(tp: int, n_predicted: int, n_gold: int) -> Dict[str, float]:
        precision = tp / n_predicted if n_predicted else 0
        recall = tp / n_gold if n_gold else 0
        f1 = (
            2 * precision * recall / (precision + recall)
            if (precision + recall) > 0
            else 0
        )
        return {
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1_score": round(f1, 4),
        }

    def _fuzzy_match_count(
        self,
        predicted: set,
        gold_set: set,
    ) -> Tuple[int, List[Tuple[str, str]]]:
        """
        Greedy one-to-one fuzzy matching between predicted and gold triples.
        Each gold triple can be matched by at most one predicted triple
        (and vice versa), so this doesn't inflate recall by letting one
        gold fact be "found" multiple times.
        """
        gold_remaining = list(gold_set)
        matched_pairs: List[Tuple[str, str]] = []
        tp = 0

        for p in predicted:
            best_idx, best_score = None, 0.0
            for i, g in enumerate(gold_remaining):
                score = min(
                    fuzz.token_sort_ratio(p[0], g[0]),
                    fuzz.token_sort_ratio(p[1], g[1]),
                    fuzz.token_sort_ratio(p[2], g[2]),
                )
                if score > best_score:
                    best_idx, best_score = i, score

            if best_idx is not None and best_score >= self.fuzzy_threshold:
                tp += 1
                matched_pairs.append(
                    (" | ".join(p), " | ".join(gold_remaining[best_idx]))
                )
                gold_remaining.pop(best_idx)

        return tp, matched_pairs

    # ── Report writing ────────────────────────────────────────────────────

    def _write_report(self, results: Dict[str, Any]) -> None:
        lines = []
        lines.append("=" * 60)
        lines.append("  KNOWLEDGE GRAPH PIPELINE — EVALUATION REPORT")
        lines.append("=" * 60)

        lines.append("\n[ GRAPH STRUCTURE ]")
        g = results["graph"]
        lines.append(f"  Nodes (entities):  {g.get('nodes', 0)}")
        lines.append(f"  Edges (relations): {g.get('edges', 0)}")
        lines.append(f"  Graph density:     {g.get('density', 0):.4f}")

        lines.append("\n[ EXTRACTION ]")
        e = results["extraction"]
        lines.append(f"  Raw triples extracted:    {e['total_raw_triples']}")
        lines.append(f"  Resolved triples:         {e['total_resolved_triples']}")
        lines.append(f"  Unique relation types:    {e['unique_relations']}")
        lines.append(f"  Avg triples per chunk:    {e['avg_triples_per_chunk']}")
        lines.append("\n  Triples per document:")
        for doc, count in e["triples_per_document"].items():
            lines.append(f"    {doc}: {count}")

        lines.append("\n[ ENTITY COVERAGE ]")
        ec = results["entity_coverage"]
        lines.append(f"  Unique entities:          {ec['unique_entities']}")
        lines.append(f"  Appear as subject only:   {ec['entities_as_subject_only']}")
        lines.append(f"  Appear as object only:    {ec['entities_as_object_only']}")
        lines.append(f"  Appear in both roles:     {ec['entities_in_both_roles']}")
        lines.append("\n  Entity type distribution:")
        for etype, count in sorted(ec["entity_type_distribution"].items(), key=lambda x: -x[1]):
            lines.append(f"    {etype}: {count}")

        lines.append("\n[ ENTITY RESOLUTION ]")
        r = results["resolution"]
        lines.append(f"  Strings before resolution: {r['total_entity_strings_before_resolution']}")
        lines.append(f"  Canonical entities after:  {r['canonical_entities_after_resolution']}")
        lines.append(f"  Aliases merged:            {r['aliases_merged']}")
        lines.append(f"  Largest alias group:       {r['largest_alias_group_size']}")

        lines.append("\n[ RELATION ANALYSIS ]")
        ra = results["relation_analysis"]
        lines.append(f"  Unique relation types:     {ra['unique_relation_types']}")
        lines.append(f"  Average confidence:        {ra['average_confidence']}")
        lines.append(f"  Low-confidence triples:    {ra['low_confidence_triples_count']}")
        lines.append("\n  Most common relations:")
        for rel, count in ra["most_common_relations"]:
            lines.append(f"    {rel}: {count}")

        lines.append("\n[ HALLUCINATION / GROUNDING CHECK ]")
        hc = results.get("hallucination_check", {})
        if "note" in hc:
            lines.append(f"  {hc['note']}")
        else:
            lines.append(f"  Triples checked:              {hc['triples_checked']}")
            lines.append(f"  Verified (grounded):          {hc['verified_triples']}")
            lines.append(f"  Unverified (likely hallucinated): {hc['unverified_triples']}")
            lines.append(f"  Estimated hallucination rate: {hc['estimated_hallucination_rate']:.2%}")
            lines.append(f"  Average grounding score:      {hc['average_grounding_score']}/100")
            if hc.get("llm_verification_calls"):
                lines.append(f"  LLM verification calls made:  {hc['llm_verification_calls']}")
            if hc.get("unverified_examples"):
                lines.append("\n  Example unverified triples:")
                for ex in hc["unverified_examples"]:
                    lines.append(f"    {ex}")

        lines.append("\n[ GOLD STANDARD EVALUATION ]")
        gs = results["gold_standard"]
        if "note" in gs:
            lines.append(f"  {gs['note']}")
        else:
            lines.append(f"  Gold triples:    {gs['gold_triples']}")
            lines.append(f"  Predicted:       {gs['predicted_triples']}")

            em = gs["exact_match"]
            lines.append("\n  Exact match:")
            lines.append(f"    True positives:  {em['true_positives']}")
            lines.append(f"    Precision:       {em['precision']:.4f}")
            lines.append(f"    Recall:          {em['recall']:.4f}")
            lines.append(f"    F1 Score:        {em['f1_score']:.4f}")

            if "fuzzy_match" in gs:
                fm = gs["fuzzy_match"]
                lines.append(f"\n  Fuzzy match (threshold={fm['threshold']}):")
                lines.append(f"    True positives:  {fm['true_positives']}")
                lines.append(f"    Precision:       {fm['precision']:.4f}")
                lines.append(f"    Recall:          {fm['recall']:.4f}")
                lines.append(f"    F1 Score:        {fm['f1_score']:.4f}")

        lines.append("\n" + "=" * 60)

        report = "\n".join(lines)
        print(report)

        out = self.output_dir / "evaluation_report.txt"
        out.write_text(report)
        logger.info(f"Evaluation report saved → {out}")

    def _write_json(self, results: Dict[str, Any]) -> None:
        out = self.output_dir / "evaluation_results.json"

        def make_serializable(obj):
            if isinstance(obj, dict):
                return {k: make_serializable(v) for k, v in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [make_serializable(i) for i in obj]
            elif isinstance(obj, set):
                return sorted(list(obj))
            elif isinstance(obj, Path):
                return str(obj)
            return obj

        out.write_text(json.dumps(make_serializable(results), indent=2))


class EvaluationManager(Evaluator):
    """
    Step 9 — Evaluation for the Multi-LLM Consensus Verification Framework.

    Extends the base Evaluator (kept fully intact above for backward
    compatibility / legacy single-model runs) with:
      - Per-model statistics (generated / accepted / rejected / avg
        agreement score per model)
      - Consensus graph statistics (nodes, edges, density, entity
        diversity, relation diversity) — via the existing graph_stats dict
      - Hallucination statistics under the new framework (accepted,
        rejected, acceptance rate, agreement score distribution)
      - Gold-standard precision/recall/F1 (reuses Evaluator exactly)
      - Single-model graph vs. Consensus graph comparison, reporting the
        improvement the consensus framework provides over any one model
        alone.
    """

    def evaluate_consensus(
        self,
        triples_by_model: Dict[str, List[Triple]],
        all_verified_triples: List[Triple],
        accepted_triples: List[Triple],
        rejected_triples: List[Triple],
        resolved_triples: List[Triple],
        resolver: EntityResolver,
        graph_stats: Dict[str, Any],
        extraction_stats: Optional[Dict[str, Any]] = None,
        verification_stats: Optional[Dict[str, Any]] = None,
        consensus_stats: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        results: Dict[str, Any] = {}

        results["graph"] = graph_stats
        results["extraction"] = self._extraction_stats(
            raw=[t for triples in triples_by_model.values() for t in triples],
            resolved=resolved_triples,
        )
        results["entity_coverage"] = self._entity_coverage(resolved_triples)
        results["relation_analysis"] = self._relation_analysis(resolved_triples)
        results["resolution"] = self._resolution_stats(resolver)

        results["per_model_stats"] = self._per_model_stats(triples_by_model, accepted_triples)
        results["consensus"] = self._consensus_stats(
            all_verified_triples, accepted_triples, rejected_triples, consensus_stats
        )
        if extraction_stats:
            results["pipeline_extraction_summary"] = extraction_stats
        if verification_stats:
            results["pipeline_verification_summary"] = verification_stats

        if self.gold_standard_path and Path(self.gold_standard_path).exists():
            results["gold_standard"] = self._gold_standard_eval(resolved_triples)
            results["single_vs_consensus"] = self._single_vs_consensus(
                triples_by_model, resolved_triples
            )
        else:
            results["gold_standard"] = {
                "note": "No gold standard provided. Add a gold_standard.txt file to enable precision/recall."
            }

        self._write_consensus_report(results)
        self._write_json(results)
        return results

    # ── New sections (Step 9) ───────────────────────────────────────────

    def _per_model_stats(
        self, triples_by_model: Dict[str, List[Triple]], accepted_triples: List[Triple]
    ) -> Dict[str, Any]:
        """
        Per-model breakdown of the consensus rule (Step 6).

        `triples_accepted` / `triples_rejected` are counted from each
        triple's own `consensus_status`, which
        src/consensus.py::ConsensusManager.select_consensus sets directly
        on these SAME Triple objects (triples_by_model and the
        all_verified/accepted/rejected lists in src/pipeline.py all
        reference the same instances) BEFORE the deduplication step runs.
        This guarantees triples_generated == triples_accepted +
        triples_rejected for every model, exactly mirroring the real
        candidate-triple processing logic (extract -> verify -> accept/
        reject by MIN_AGREEMENT_SCORE).

        `accepted_triples` (the de-duplicated Consensus Knowledge Graph)
        is used only for the separate `triples_in_final_graph` count: a
        triple can pass the consensus rule (accepted) but still not be
        its own edge in the final graph if another model independently
        produced the same fact and was picked as the representative
        instance during dedup (Step 7) — that is NOT the same thing as
        being rejected, so it must not be counted as rejected.
        """
        in_final_graph: Dict[str, int] = defaultdict(int)
        for t in accepted_triples:
            in_final_graph[t.generator_model] += 1

        stats: Dict[str, Any] = {}
        for model, triples in triples_by_model.items():
            n_generated = len(triples)
            n_accepted = sum(1 for t in triples if t.consensus_status == "accepted")
            n_rejected = n_generated - n_accepted
            avg_agreement = (
                round(sum(t.agreement_score or 0.0 for t in triples) / n_generated, 4)
                if n_generated else 0.0
            )
            stats[model] = {
                "triples_generated": n_generated,
                "triples_accepted": n_accepted,
                "triples_rejected": n_rejected,
                "acceptance_rate": round(n_accepted / n_generated, 4) if n_generated else 0.0,
                "average_agreement_score": avg_agreement,
                # Informational only (not part of the accepted/rejected
                # invariant above): how many of this model's triples ended
                # up as the actual edge written into the final,
                # de-duplicated Consensus Knowledge Graph.
                "triples_in_final_graph": in_final_graph.get(model, 0),
            }
        return stats

    def _consensus_stats(
        self,
        all_verified: List[Triple],
        accepted: List[Triple],
        rejected: List[Triple],
        consensus_manager_stats: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        `all_verified` is every triple that went through cross-verification
        (Step 3-4) — i.e. every candidate triple. `rejected` is exactly the
        subset of those whose agreement_score fell below
        MIN_AGREEMENT_SCORE (src/consensus.py::ConsensusManager
        .select_consensus splits all_verified into accepted/rejected with
        no triple dropped in between, so
        len(all_verified) == accepted_before_dedup + len(rejected) always).

        `accepted` (the `accepted_triples` argument passed in from
        src/pipeline.py) is already the de-duplicated Consensus Knowledge
        Graph — some triples that individually passed the consensus rule
        are merged into another model's identical fact and no longer
        appear as a separate entry. Reporting len(accepted) here would
        make "accepted + rejected" NOT sum to "total_candidate_triples"
        whenever any duplicate facts were merged.

        To keep the headline accepted/rejected/total numbers internally
        consistent (accepted + rejected == total_candidate_triples) and
        the acceptance rate a faithful Accepted/Total, "accepted" below is
        the pre-deduplication count that already exists on
        consensus_manager_stats (src/consensus.py::ConsensusManager
        .last_stats["accepted_before_dedup"]) — the number of triples that
        actually passed the consensus rule. The separate, smaller,
        post-dedup graph size (what's actually written to Neo4j / exports)
        is kept available as "consensus_graph_triples" so nothing is lost,
        just correctly labelled.
        """
        total = len(all_verified)
        distribution: Dict[str, int] = defaultdict(int)
        for t in all_verified:
            score = t.agreement_score if t.agreement_score is not None else 0.0
            distribution[f"{score:.2f}"] += 1

        if consensus_manager_stats and "accepted_before_dedup" in consensus_manager_stats:
            accepted_count = consensus_manager_stats["accepted_before_dedup"]
        else:
            # Fallback for callers that don't supply consensus_manager_stats
            # (should not happen from src/pipeline.py, but avoids a crash).
            accepted_count = len(accepted)

        result = {
            "total_candidate_triples": total,
            "accepted": accepted_count,
            "rejected": len(rejected),
            "acceptance_rate": round(accepted_count / total, 4) if total else 0.0,
            # Post-deduplication Consensus Knowledge Graph size — the
            # number of edges actually written to the graph. Distinct from
            # "accepted" above whenever cross-model duplicate facts were
            # merged (see "deduplication" below).
            "consensus_graph_triples": len(accepted),
            "agreement_score_distribution": dict(sorted(distribution.items())),
            "average_agreement_score": (
                round(sum(t.agreement_score or 0.0 for t in all_verified) / total, 4)
                if total else 0.0
            ),
        }
        if consensus_manager_stats:
            result["deduplication"] = consensus_manager_stats
        return result

    def _single_vs_consensus(
        self,
        triples_by_model: Dict[str, List[Triple]],
        consensus_triples: List[Triple],
    ) -> Dict[str, Any]:
        """
        Compares each individual model's raw (unverified) graph against
        the final Consensus Knowledge Graph on gold-standard precision /
        recall / F1, and reports the improvement the consensus framework
        provides over using any single model alone.
        """
        comparison: Dict[str, Any] = {}
        for model, triples in triples_by_model.items():
            comparison[model] = self._gold_standard_eval(triples)

        consensus_eval = self._gold_standard_eval(consensus_triples)
        comparison["consensus"] = consensus_eval

        improvement: Dict[str, Any] = {}
        for model in triples_by_model:
            single_f1 = comparison[model].get("f1_score", 0.0)
            consensus_f1 = consensus_eval.get("f1_score", 0.0)
            improvement[model] = {
                "single_model_f1": single_f1,
                "consensus_f1": consensus_f1,
                "absolute_f1_improvement": round(consensus_f1 - single_f1, 4),
                "relative_f1_improvement_pct": (
                    round(100 * (consensus_f1 - single_f1) / single_f1, 2)
                    if single_f1 else None
                ),
            }
        comparison["improvement_over_single_model"] = improvement
        return comparison

    # ── Report writing (consensus variant) ──────────────────────────────

    def _write_consensus_report(self, results: Dict[str, Any]) -> None:
        lines = []
        lines.append("=" * 60)
        lines.append("  MULTI-LLM CONSENSUS KNOWLEDGE GRAPH — EVALUATION REPORT")
        lines.append("=" * 60)

        lines.append("\n[ CONSENSUS GRAPH STRUCTURE ]")
        g = results["graph"]
        lines.append(f"  Nodes (entities):  {g.get('nodes', 0)}")
        lines.append(f"  Edges (relations): {g.get('edges', 0)}")
        lines.append(f"  Graph density:     {g.get('density', 0):.4f}")
        lines.append(f"  Entity diversity (types):   {len(g.get('entity_types', {}))}")
        lines.append(f"  Relation diversity (types): {len(g.get('relation_types', {}))}")

        lines.append("\n[ PER-MODEL STATISTICS ]")
        for model, s in results.get("per_model_stats", {}).items():
            lines.append(f"  {model}:")
            lines.append(f"    Triples generated:      {s['triples_generated']}")
            lines.append(f"    Triples accepted:       {s['triples_accepted']}")
            lines.append(f"    Triples rejected:       {s['triples_rejected']}")
            lines.append(f"    Acceptance rate:        {s['acceptance_rate']:.2%}")
            lines.append(f"    Average agreement score:{s['average_agreement_score']}")

        lines.append("\n[ CONSENSUS / HALLUCINATION REDUCTION ]")
        c = results.get("consensus", {})
        lines.append(f"  Candidate triples (all models):   {c.get('total_candidate_triples', 0)}")
        lines.append(f"  Accepted (passed consensus rule): {c.get('accepted', 0)}")
        lines.append(f"  Rejected:                          {c.get('rejected', 0)}")
        lines.append(f"  Acceptance rate:                   {c.get('acceptance_rate', 0):.2%}")
        lines.append(f"  Final consensus graph triples (post-dedup): {c.get('consensus_graph_triples', 0)}")
        lines.append(f"  Average agreement score:           {c.get('average_agreement_score', 0)}")
        lines.append("  Agreement score distribution:")
        for score, count in c.get("agreement_score_distribution", {}).items():
            lines.append(f"    {score}: {count}")
        dedup = c.get("deduplication", {})
        if dedup:
            lines.append(f"  Cross-model duplicate facts merged: {dedup.get('duplicate_facts_merged', 0)}")

        lines.append("\n[ ENTITY RESOLUTION ]")
        r = results["resolution"]
        lines.append(f"  Strings before resolution: {r['total_entity_strings_before_resolution']}")
        lines.append(f"  Canonical entities after:  {r['canonical_entities_after_resolution']}")
        lines.append(f"  Aliases merged:            {r['aliases_merged']}")

        lines.append("\n[ GOLD STANDARD EVALUATION ]")
        gs = results.get("gold_standard", {})
        if "note" in gs:
            lines.append(f"  {gs['note']}")
        else:
            lines.append(f"  Gold triples:    {gs['gold_triples']}")
            lines.append(f"  Predicted:       {gs['predicted_triples']}")
            em = gs["exact_match"]
            lines.append("\n  Exact match:")
            lines.append(f"    Precision: {em['precision']:.4f}  Recall: {em['recall']:.4f}  F1: {em['f1_score']:.4f}")
            if "fuzzy_match" in gs:
                fm = gs["fuzzy_match"]
                lines.append(f"\n  Fuzzy match (threshold={fm['threshold']}):")
                lines.append(f"    Precision: {fm['precision']:.4f}  Recall: {fm['recall']:.4f}  F1: {fm['f1_score']:.4f}")

        if "single_vs_consensus" in results:
            lines.append("\n[ SINGLE MODEL vs. CONSENSUS GRAPH ]")
            svc = results["single_vs_consensus"]
            improvement = svc.get("improvement_over_single_model", {})
            for model, imp in improvement.items():
                lines.append(
                    f"  {model}: single F1={imp['single_model_f1']:.4f}  "
                    f"consensus F1={imp['consensus_f1']:.4f}  "
                    f"Δ={imp['absolute_f1_improvement']:+.4f}"
                    + (
                        f" ({imp['relative_f1_improvement_pct']:+.1f}%)"
                        if imp["relative_f1_improvement_pct"] is not None else ""
                    )
                )

        lines.append("\n" + "=" * 60)

        report = "\n".join(lines)
        print(report)

        out = self.output_dir / "evaluation_report.txt"
        out.write_text(report)
        logger.info(f"Consensus evaluation report saved → {out}")
