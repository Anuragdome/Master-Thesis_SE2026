"""
tests/test_pipeline.py
======================
Unit tests for each stage of the KG pipeline.

Run with:
    pytest tests/ -v
"""

import pytest
from pathlib import Path
import tempfile
import sys
import os

# Ensure the project root is on the path
sys.path.insert(0, str(Path(__file__).parent.parent))


# ── Stage 1: Ingestion ────────────────────────────────────────────────────────

class TestIngestion:

    def test_ingest_txt_file(self):
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester(chunk_size=200, chunk_overlap=20)

        with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", delete=False) as f:
            f.write("Marie Curie won the Nobel Prize in Physics. " * 10)
            path = Path(f.name)

        try:
            chunks = ingester._process_file(path)
            assert len(chunks) > 0
            assert all(c.text for c in chunks)
            assert all(c.source_file == path.name for c in chunks)
        finally:
            path.unlink()

    def test_chunk_overlap(self):
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester(chunk_size=100, chunk_overlap=20)
        text = "A" * 300
        chunks = ingester._chunk_text(text, "test")
        assert len(chunks) > 1
        # Verify overlap: end of chunk n overlaps with start of chunk n+1
        for i in range(len(chunks) - 1):
            # Some overlap expected
            assert len(chunks[i].text) >= 80

    def test_clean_text(self):
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester()
        dirty = "Hello\r\n\r\n\r\nWorld   extra   spaces"
        clean = ingester._clean_text(dirty)
        assert "\r" not in clean
        assert "\n\n\n" not in clean
        assert "   " not in clean

    def test_ingest_directory_generates_samples(self):
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester()
        with tempfile.TemporaryDirectory() as tmpdir:
            chunks = ingester.ingest_directory(Path(tmpdir))
            assert len(chunks) > 0  # Sample documents generated


# ── Stage 2: Extraction ───────────────────────────────────────────────────────

class TestExtraction:

    def test_parse_valid_json(self):
        from src.ingestion import DocumentChunk
        from src.extraction import LLMExtractor

        extractor = LLMExtractor()
        chunk = DocumentChunk(
            chunk_id="test_0001", source_file="test.txt", chunk_index=0, text="test"
        )
        raw = '{"triples": [{"subject": "Marie Curie", "subject_type": "PERSON", "relation": "won", "object": "Nobel Prize", "object_type": "CONCEPT", "confidence": 0.99}]}'
        triples = extractor._parse_response(raw, chunk)
        assert len(triples) == 1
        assert triples[0].subject == "Marie Curie"
        assert triples[0].relation == "won"
        assert triples[0].object == "Nobel Prize"

    def test_parse_handles_markdown_fences(self):
        from src.ingestion import DocumentChunk
        from src.extraction import LLMExtractor
        extractor = LLMExtractor()
        chunk = DocumentChunk(
            chunk_id="test_0001", source_file="test.txt", chunk_index=0, text="test"
        )
        raw = '```json\n{"triples": []}\n```'
        triples = extractor._parse_response(raw, chunk)
        assert triples == []

    def test_parse_invalid_json_returns_empty(self):
        from src.ingestion import DocumentChunk
        from src.extraction import LLMExtractor
        extractor = LLMExtractor()
        chunk = DocumentChunk(
            chunk_id="test_0001", source_file="test.txt", chunk_index=0, text="test"
        )
        triples = extractor._parse_response("not json at all", chunk)
        assert triples == []

    def test_skips_triples_with_empty_fields(self):
        from src.ingestion import DocumentChunk
        from src.extraction import LLMExtractor
        extractor = LLMExtractor()
        chunk = DocumentChunk(
            chunk_id="test_0001", source_file="test.txt", chunk_index=0, text="test"
        )
        raw = '{"triples": [{"subject": "", "subject_type": "PERSON", "relation": "won", "object": "Nobel Prize", "object_type": "CONCEPT", "confidence": 0.9}]}'
        triples = extractor._parse_response(raw, chunk)
        assert len(triples) == 0


# ── Stage 3: Entity Resolution ────────────────────────────────────────────────

class TestResolution:

    def _make_triples(self, data):
        from src.extraction import Triple
        return [
            Triple(subject=s, subject_type=st, relation=r, object=o, object_type=ot)
            for s, st, r, o, ot in data
        ]

    def test_exact_duplicates_merged(self):
        from src.resolution import EntityResolver
        resolver = EntityResolver(similarity_threshold=0.85, use_semantic=False)
        triples = self._make_triples([
            ("Marie Curie", "PERSON", "won", "Nobel Prize", "CONCEPT"),
            ("Marie Curie", "PERSON", "born_in", "Warsaw", "LOCATION"),
        ])
        resolved = resolver.resolve(triples)
        assert len(resolved) == 2

    def test_canonical_map_built(self):
        from src.resolution import EntityResolver
        resolver = EntityResolver(similarity_threshold=0.85, use_semantic=False)
        triples = self._make_triples([
            ("Marie Curie", "PERSON", "won", "Nobel Prize", "CONCEPT"),
        ])
        resolver.resolve(triples)
        assert "Marie Curie" in resolver.canonical_map

    def test_entity_summary_non_empty(self):
        from src.resolution import EntityResolver
        resolver = EntityResolver(similarity_threshold=0.85, use_semantic=False)
        triples = self._make_triples([
            ("Einstein", "PERSON", "developed", "Relativity", "CONCEPT"),
        ])
        resolver.resolve(triples)
        summary = resolver.get_entity_summary()
        assert len(summary) > 0
        assert all("name" in e and "type" in e for e in summary)


# ── Stage 4: Graph Builder ────────────────────────────────────────────────────

class TestGraphBuilder:

    def _make_triples(self, data):
        from src.extraction import Triple
        return [Triple(subject=s, subject_type=st, relation=r, object=o, object_type=ot)
                for s, st, r, o, ot in data]

    def test_graph_builds_with_correct_node_count(self):
        from src.graph_builder import GraphBuilder
        with tempfile.TemporaryDirectory() as tmpdir:
            builder = GraphBuilder(neo4j_enabled=False, output_dir=Path(tmpdir))
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
                ("Bob", "PERSON", "works_at", "Acme", "ORGANIZATION"),
            ])
            stats = builder.build(triples)
            assert stats["nodes"] == 3  # Alice, Bob, Acme
            assert stats["edges"] == 2

    def test_exports_json_and_csv(self):
        from src.graph_builder import GraphBuilder
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            builder = GraphBuilder(neo4j_enabled=False, output_dir=tmpdir)
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
            ])
            builder.build(triples)
            assert (tmpdir / "triples.json").exists()
            assert (tmpdir / "triples.csv").exists()
            assert (tmpdir / "import_graph.cypher").exists()


# ── Stage 5: Evaluation ───────────────────────────────────────────────────────

class TestEvaluation:

    def _make_triples(self, data):
        from src.extraction import Triple
        return [Triple(subject=s, subject_type=st, relation=r, object=o, object_type=ot)
                for s, st, r, o, ot in data]

    def test_evaluation_runs_without_gold(self):
        from src.evaluation import Evaluator
        from src.resolution import EntityResolver
        with tempfile.TemporaryDirectory() as tmpdir:
            evaluator = Evaluator(output_dir=Path(tmpdir))
            resolver = EntityResolver(use_semantic=False)
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
            ])
            resolver.resolve(triples)
            results = evaluator.evaluate(
                raw_triples=triples,
                resolved_triples=triples,
                resolver=resolver,
                graph_stats={"nodes": 2, "edges": 1, "density": 1.0},
            )
            assert "graph" in results
            assert "extraction" in results
            assert "entity_coverage" in results

    def test_gold_standard_precision_recall(self):
        from src.evaluation import Evaluator
        from src.resolution import EntityResolver
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            gold_path = tmpdir / "gold.txt"
            gold_path.write_text("Alice | knows | Bob\nAlice | works_at | Acme\n")

            evaluator = Evaluator(output_dir=tmpdir, gold_standard_path=gold_path)
            resolver = EntityResolver(use_semantic=False)
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
                ("Alice", "PERSON", "lives_in", "NYC", "LOCATION"),  # false positive
            ])
            resolver.resolve(triples)
            results = evaluator.evaluate(
                raw_triples=triples, resolved_triples=triples,
                resolver=resolver,
                graph_stats={"nodes": 3, "edges": 2, "density": 0.33},
            )
            gs = results["gold_standard"]
            assert gs["true_positives"] == 1
            assert gs["precision"] == pytest.approx(0.5, abs=0.01)
            assert gs["recall"] == pytest.approx(0.5, abs=0.01)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
