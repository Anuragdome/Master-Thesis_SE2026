"""
src/providers.py
=================
LLM Provider abstraction for the Multi-LLM Consensus Verification Framework.

Each provider wraps ONE model (Gemini via the hosted API, or Llama / Qwen
running locally through Ollama) behind a common async interface:

    await provider.extract_triples_raw(chunk_text)      -> raw JSON string
    await provider.verify_triple_raw(source_text, triple_str) -> raw JSON string

Keeping this as a thin, uniform interface is what lets
src/extraction.py::MultiLLMExtractor and
src/verification.py::VerificationManager treat Gemini/Llama/Qwen
interchangeably and run them concurrently with asyncio.gather, satisfying
the "Independent Extraction" (Step 1) and "Cross Verification" (Step 3)
requirements without duplicating orchestration code per model.

Class hierarchy:

    BaseLLM (ABC)
    ├── GeminiProvider      — hosted Gemini API (google-genai SDK)
    └── OllamaProvider      — local models served by Ollama's REST API
        ├── LlamaProvider   — Llama 3.1 8B
        └── QwenProvider    — Qwen 3 8B
"""

from __future__ import annotations

import abc
import asyncio
import json
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# ── Shared prompts ──────────────────────────────────────────────────────────
# Reused verbatim from src/extraction.py::LLMExtractor so all three models
# are given the *exact same* extraction task — a prerequisite for a fair
# multi-model consensus comparison.

EXTRACTION_SYSTEM_PROMPT = """You are an expert knowledge graph builder.
Your task is to extract entities and relationships from text and return them as structured JSON.

Rules:
1. Extract only EXPLICIT facts stated in the text. Do not infer or add external knowledge.
2. Each triple must have a subject, a relation verb, and an object.
3. Entity types must be one of: PERSON, ORGANIZATION, LOCATION, CONCEPT, EVENT, PRODUCT, DATE, TECHNOLOGY
4. Relations should be short verb phrases in snake_case (e.g. works_for, located_in, founded_by).
5. Names should be in canonical form (full names preferred).
6. Return ONLY valid JSON. No explanation, no markdown, no preamble.

Output format:
{
  "triples": [
    {
      "subject": "entity name",
      "subject_type": "ENTITY_TYPE",
      "relation": "relation_verb",
      "object": "entity name",
      "object_type": "ENTITY_TYPE",
      "confidence": 0.95
    }
  ]
}

If no clear entities or relations are found, return: {"triples": []}"""

FEW_SHOT_EXAMPLE = """
Example:
Text: "Marie Curie won the Nobel Prize in Physics in 1903. She worked at the University of Paris."

Output:
{
  "triples": [
    {"subject": "Marie Curie", "subject_type": "PERSON", "relation": "won", "object": "Nobel Prize in Physics", "object_type": "CONCEPT", "confidence": 0.99},
    {"subject": "Nobel Prize in Physics", "subject_type": "CONCEPT", "relation": "awarded_in", "object": "1903", "object_type": "DATE", "confidence": 0.99},
    {"subject": "Marie Curie", "subject_type": "PERSON", "relation": "worked_at", "object": "University of Paris", "object_type": "ORGANIZATION", "confidence": 0.97}
  ]
}
"""

# Cross-verification prompt (Step 3 / Step 4). Deliberately strict: a
# verifying model must point at the exact sentence that supports the
# triple, and must never invent evidence for a NOT_SUPPORTED triple.
VERIFICATION_SYSTEM_PROMPT = """You are a strict fact-checker for a multi-model knowledge graph consensus \
pipeline. You will be given a source passage and ONE (subject, relation, object) triple that another \
extraction model claims is stated in that passage.

Determine whether this triple is explicitly supported by the provided source text.

Rules:
- Judge only against the given passage. Do not use outside/world knowledge.
- Paraphrases and synonyms that are directly spelled out in the passage count as supported.
- Anything invented, only loosely implied, guessed, or contradicted by the passage is NOT supported.
- If supported, "evidence" must be the exact sentence (verbatim substring of the passage) that supports it.
- If NOT supported, you MUST return an empty string for "evidence". Never invent/hallucinate evidence.
- Return JSON only. No markdown, no explanation, no preamble.

Output format:
{"supported": true, "evidence": "exact supporting sentence copied verbatim from the passage"}
or
{"supported": false, "evidence": ""}"""


def build_extraction_prompt(chunk_text: str) -> str:
    return f"""{FEW_SHOT_EXAMPLE}

Now extract all entities and relationships from the following text:

Text: \"\"\"{chunk_text}\"\"\"

Return only valid JSON."""


def build_verification_prompt(source_text: str, triple_str: str) -> str:
    return f"""Source text:
\"\"\"{source_text}\"\"\"

Triple: {triple_str}

Determine whether this triple is explicitly supported by the provided source text.
Return JSON only.
{{"supported": true/false, "evidence": "exact supporting sentence"}}"""


class BaseLLM(abc.ABC):
    """
    Common interface every LLM provider in the consensus framework
    implements. Subclasses only need to implement `_generate`, the raw
    "system prompt + user prompt -> text" call for that backend; prompt
    construction and JSON-shape are shared here so extraction and
    verification behave identically across Gemini/Llama/Qwen.
    """

    #: short identifier used everywhere as the "generator"/"verifier" name
    #: (stored on Triple.generator_model, verification_results[*]["verifier"], etc.)
    name: str = "base"

    def __init__(
        self,
        model_name: str,
        max_tokens: int = 2000,
        temperature: float = 0.0,
        max_concurrency: int = 4,
    ):
        self.model_name = model_name
        self.max_tokens = max_tokens
        self.temperature = temperature
        self._semaphore = asyncio.Semaphore(max(1, max_concurrency))

    # ── Low-level hook subclasses implement ─────────────────────────────
    @abc.abstractmethod
    async def _generate(self, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
        """Call the underlying model and return its raw text response."""
        raise NotImplementedError

    # ── Public API used by MultiLLMExtractor / VerificationManager ─────
    async def extract_triples_raw(self, chunk_text: str) -> str:
        """Step 1: independent extraction. Returns raw JSON text (untouched)."""
        prompt = build_extraction_prompt(chunk_text)
        async with self._semaphore:
            return await self._generate(EXTRACTION_SYSTEM_PROMPT, prompt, self.max_tokens)

    async def verify_triple_raw(self, source_text: str, triple_str: str) -> str:
        """Step 3/4: cross verification. Returns raw JSON text (untouched)."""
        prompt = build_verification_prompt(source_text, triple_str)
        async with self._semaphore:
            return await self._generate(VERIFICATION_SYSTEM_PROMPT, prompt, 300)

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"<{self.__class__.__name__} name={self.name!r} model={self.model_name!r}>"


class GeminiProvider(BaseLLM):
    """Hosted Gemini API (google-genai SDK). The google-genai client is
    synchronous, so calls are off-loaded to a worker thread with
    `asyncio.to_thread` to keep the pipeline fully async without blocking
    the event loop that Llama/Qwen's aiohttp calls run on."""

    name = "gemini"

    def __init__(
        self,
        api_key: str,
        model_name: str = "gemini-2.5-flash",
        max_tokens: int = 2000,
        temperature: float = 0.0,
        max_concurrency: int = 4,
    ):
        super().__init__(model_name, max_tokens, temperature, max_concurrency)
        self.api_key = api_key
        self._client = None

    def _get_client(self):
        if self._client is None:
            from google import genai
            self._client = genai.Client(api_key=self.api_key)
        return self._client

    async def _generate(self, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
        def _call() -> str:
            client = self._get_client()
            full_prompt = system_prompt + "\n\n" + user_prompt
            response = client.models.generate_content(
                model=self.model_name,
                contents=full_prompt,
            )
            return response.text or ""

        try:
            return await asyncio.to_thread(_call)
        except Exception as e:
            logger.error(f"[gemini] generation failed: {e}")
            raise


class OllamaProvider(BaseLLM):
    """
    Base class for models served locally through Ollama
    (http://localhost:11434 by default — see config.settings.OLLAMA_URL).

    Uses Ollama's `/api/generate` endpoint with `stream=False` and
    `format="json"` so the model is constrained to emit valid JSON
    wherever the backend supports it, with a defensive parser on top
    regardless (see extraction.py / verification.py parsers).
    """

    name = "ollama"

    def __init__(
        self,
        model_name: str,
        base_url: str = "http://localhost:11434",
        max_tokens: int = 2000,
        temperature: float = 0.0,
        max_concurrency: int = 4,
        request_timeout: float = 120.0,
    ):
        super().__init__(model_name, max_tokens, temperature, max_concurrency)
        self.base_url = base_url.rstrip("/")
        self.request_timeout = request_timeout

    async def _generate(self, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
        import aiohttp

        url = f"{self.base_url}/api/generate"
        payload = {
            "model": self.model_name,
            "system": system_prompt,
            "prompt": user_prompt,
            "stream": False,
            "format": "json",
            "options": {
                "temperature": self.temperature,
                "num_predict": max_tokens,
            },
        }

        timeout = aiohttp.ClientTimeout(total=self.request_timeout)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, json=payload) as resp:
                    resp.raise_for_status()
                    data = await resp.json()
                    return data.get("response", "")
        except Exception as e:
            logger.error(
                f"[{self.name}] Ollama request to {url} failed: {e}. "
                f"Is 'ollama serve' running and has '{self.model_name}' been pulled? "
                f"(ollama pull {self.model_name})"
            )
            raise


class LlamaProvider(OllamaProvider):
    """Llama 3.1 8B, run locally through Ollama."""

    name = "llama"

    def __init__(
        self,
        model_name: str = "llama3.1:8b",
        base_url: str = "http://localhost:11434",
        max_tokens: int = 2000,
        temperature: float = 0.0,
        max_concurrency: int = 4,
    ):
        super().__init__(model_name, base_url, max_tokens, temperature, max_concurrency)


class QwenProvider(OllamaProvider):
    """Qwen 3 8B, run locally through Ollama."""

    name = "qwen"

    def __init__(
        self,
        model_name: str = "qwen3:8b",
        base_url: str = "http://localhost:11434",
        max_tokens: int = 2000,
        temperature: float = 0.0,
        max_concurrency: int = 4,
    ):
        super().__init__(model_name, base_url, max_tokens, temperature, max_concurrency)


def build_providers_from_settings(cfg) -> "dict[str, BaseLLM]":
    """
    Factory: reads config/settings.py (or an equivalent module) and
    returns an {name: BaseLLM} dict of every enabled provider. This is
    the single place that maps settings -> concrete provider instances,
    used by src/pipeline.py so the orchestrator stays provider-agnostic.
    """
    providers: "dict[str, BaseLLM]" = {}
    max_conc = getattr(cfg, "CONSENSUS_MAX_CONCURRENCY", 4)

    if getattr(cfg, "USE_GEMINI", True):
        api_key = getattr(cfg, "GEMINI_API_KEY", "")
        if api_key and "YOUR_" not in api_key:
            providers["gemini"] = GeminiProvider(
                api_key=api_key,
                model_name=getattr(cfg, "MODEL_NAME", "gemini-2.5-flash"),
                max_tokens=cfg.MAX_TOKENS,
                temperature=cfg.TEMPERATURE,
                max_concurrency=max_conc,
            )
        else:
            logger.warning("USE_GEMINI=True but no GEMINI_API_KEY set — skipping Gemini provider.")

    if getattr(cfg, "USE_LLAMA", True):
        providers["llama"] = LlamaProvider(
            model_name=getattr(cfg, "LLAMA_MODEL_NAME", "llama3.1:8b"),
            base_url=getattr(cfg, "OLLAMA_URL", "http://localhost:11434"),
            max_tokens=cfg.MAX_TOKENS,
            temperature=cfg.TEMPERATURE,
            max_concurrency=max_conc,
        )

    if getattr(cfg, "USE_QWEN", True):
        providers["qwen"] = QwenProvider(
            model_name=getattr(cfg, "QWEN_MODEL_NAME", "qwen3:8b"),
            base_url=getattr(cfg, "OLLAMA_URL", "http://localhost:11434"),
            max_tokens=cfg.MAX_TOKENS,
            temperature=cfg.TEMPERATURE,
            max_concurrency=max_conc,
        )

    return providers
