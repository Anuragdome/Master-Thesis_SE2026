"""
src/pipeline.py
===============
Pipeline Orchestrator

Runs all 5 stages in sequence:
  1. Document ingestion
  2. LLM extraction
  3. Entity resolution
  4. Graph construction
  5. Evaluation

Import and call Pipeline.run() or use run_pipeline.py as the entry point.
"""

import json
import logging
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class Pipeline:
    """
    End-to-end knowledge graph pipeline.

    Usage:
        from src.pipeline import Pipeline
        pipeline = Pipeline()
        results = pipeline.run()
    """

    def __init__(self, config_module=None):
        """
        Load settings from config/settings.py (or pass a custom module).
        """
        if config_module is None:
            import config.settings as config_module
        self.cfg = config_module

    def run(self, input_dir: Optional[Path] = None) -> dict:
        """
        Execute the full pipeline and return evaluation results.
        """
        start_time = time.time()

        logger.info("=" * 55)
        logger.info("  KNOWLEDGE GRAPH PIPELINE")
        logger.info("=" * 55)

        input_dir = input_dir or self.cfg.DATA_RAW

        # ── Stage 1: Ingestion ────────────────────────────────────────────
        logger.info("\n[ STAGE 1 ] Document Ingestion")
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester(
            chunk_size=self.cfg.CHUNK_SIZE,
            chunk_overlap=self.cfg.CHUNK_OVERLAP,
        )
        chunks = ingester.ingest_directory(input_dir)

        if not chunks:
            logger.error("No chunks produced. Aborting.")
            return {}

        self._save_intermediate(
            [{"chunk_id": c.chunk_id, "source": c.source_file, "text": c.text} for c in chunks],
            "chunks.json"
        )

        # ── Stage 2: LLM Extraction ───────────────────────────────────────
        logger.info(f"\n[ STAGE 2 ] LLM Extraction ({self.cfg.LLM_PROVIDER} / {self.cfg.MODEL_NAME})")

        #api_key = (
        #   self.cfg.ANTHROPIC_API_KEY
        #    if self.cfg.LLM_PROVIDER == "anthropic"
        #    else self.cfg.OPENAI_API_KEY
        #)
        if self.cfg.LLM_PROVIDER == "anthropic":
            api_key = self.cfg.ANTHROPIC_API_KEY
        elif self.cfg.LLM_PROVIDER == "openai":
            api_key = self.cfg.OPENAI_API_KEY
        elif self.cfg.LLM_PROVIDER == "gemini":
            api_key = self.cfg.GEMINI_API_KEY
        else:
            raise ValueError(f"Unknown LLM provider: {self.cfg.LLM_PROVIDER}")

        if "YOUR_" in api_key:
            logger.warning("No real API key set. Using mock extraction for demo.")
            raw_triples = self._mock_extraction(chunks)
        else:
            from src.extraction import LLMExtractor
            extractor = LLMExtractor(
                provider=self.cfg.LLM_PROVIDER,
                model_name=self.cfg.MODEL_NAME,
                api_key=api_key,
                max_tokens=self.cfg.MAX_TOKENS,
                temperature=self.cfg.TEMPERATURE,
            )
            raw_triples = extractor.extract_from_chunks(chunks)

        self._save_intermediate(
            [t.to_dict() for t in raw_triples],
            "raw_triples.json"
        )

        # ── Stage 3: Entity Resolution ────────────────────────────────────
        logger.info("\n[ STAGE 3 ] Entity Resolution")
        from src.resolution import EntityResolver
        resolver = EntityResolver(
            similarity_threshold=self.cfg.SIMILARITY_THRESHOLD,
            use_semantic=self.cfg.USE_SEMANTIC_SIMILARITY,
            embedding_model=self.cfg.EMBEDDING_MODEL,
        )
        resolved_triples = resolver.resolve(raw_triples)

        self._save_intermediate(
            resolver.get_entity_summary(),
            "entities.json"
        )

        # ── Stage 4: Graph Construction ───────────────────────────────────
        logger.info("\n[ STAGE 4 ] Graph Construction")
        from src.graph_builder import GraphBuilder
        builder = GraphBuilder(
            neo4j_enabled=self.cfg.NEO4J_ENABLED,
            neo4j_uri=self.cfg.NEO4J_URI,
            neo4j_user=self.cfg.NEO4J_USER,
            neo4j_password=self.cfg.NEO4J_PASSWORD,
            output_dir=self.cfg.DATA_OUTPUT,
        )
        graph_stats = builder.build(resolved_triples, resolver)

        # ── Stage 5: Evaluation ───────────────────────────────────────────
        logger.info("\n[ STAGE 5 ] Evaluation")
        from src.evaluation import Evaluator
        evaluator = Evaluator(
            output_dir=self.cfg.DATA_OUTPUT,
            gold_standard_path=self.cfg.GOLD_STANDARD_PATH,
        )
        results = evaluator.evaluate(
            raw_triples=raw_triples,
            resolved_triples=resolved_triples,
            resolver=resolver,
            graph_stats=graph_stats,
        )

        elapsed = time.time() - start_time
        logger.info(f"\nPipeline completed in {elapsed:.1f}s")
        logger.info(f"Outputs saved to: {self.cfg.DATA_OUTPUT}")

        if self.cfg.NEO4J_ENABLED:
            logger.info("Neo4j browser: http://localhost:7474")
            logger.info("  Query: MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 50")

        return results

    # ── Helpers ───────────────────────────────────────────────────────────

    def _save_intermediate(self, data, filename: str) -> None:
        path = self.cfg.DATA_PROCESSED / filename
        path.write_text(
    json.dumps(data, indent=2, ensure_ascii=False),
    encoding="utf-8"
)
        logger.debug(f"Saved intermediate: {path}")

    def _mock_extraction(self, chunks) -> list:
        """
        Returns realistic mock triples when no API key is set.
        Useful for testing the rest of the pipeline without spending API credits.
        """
        from src.extraction import Triple

        mock_data = [
            ("Marie Curie", "PERSON", "won", "Nobel Prize in Physics", "CONCEPT", 0.99),
            ("Marie Curie", "PERSON", "won", "Nobel Prize in Chemistry", "CONCEPT", 0.99),
            ("Marie Curie", "PERSON", "worked_at", "University of Paris", "ORGANIZATION", 0.97),
            ("Marie Curie", "PERSON", "born_in", "Warsaw", "LOCATION", 0.98),
            ("Marie Curie", "PERSON", "married", "Pierre Curie", "PERSON", 0.99),
            ("Pierre Curie", "PERSON", "worked_at", "University of Paris", "ORGANIZATION", 0.95),
            ("Marie Curie", "PERSON", "discovered", "Polonium", "CONCEPT", 0.99),
            ("Marie Curie", "PERSON", "discovered", "Radium", "CONCEPT", 0.99),
            ("M. Curie", "PERSON", "founded", "Curie Institute", "ORGANIZATION", 0.92),
            ("Albert Einstein", "PERSON", "developed", "Theory of Relativity", "CONCEPT", 0.99),
            ("Albert Einstein", "PERSON", "won", "Nobel Prize in Physics", "CONCEPT", 0.99),
            ("Albert Einstein", "PERSON", "worked_at", "Institute for Advanced Study", "ORGANIZATION", 0.97),
            ("Einstein", "PERSON", "born_in", "Germany", "LOCATION", 0.98),
            ("Albert Einstein", "PERSON", "collaborated_with", "Niels Bohr", "PERSON", 0.95),
            ("Albert Einstein", "PERSON", "taught_at", "ETH Zurich", "ORGANIZATION", 0.96),
            ("OpenAI", "ORGANIZATION", "founded_by", "Sam Altman", "PERSON", 0.99),
            ("OpenAI", "ORGANIZATION", "founded_by", "Elon Musk", "PERSON", 0.98),
            ("OpenAI", "ORGANIZATION", "located_in", "San Francisco", "LOCATION", 0.99),
            ("OpenAI", "ORGANIZATION", "developed", "GPT-4", "TECHNOLOGY", 0.99),
            ("OpenAI", "ORGANIZATION", "developed", "ChatGPT", "TECHNOLOGY", 0.99),
            ("Microsoft", "ORGANIZATION", "invested_in", "OpenAI", "ORGANIZATION", 0.98),
            ("Sam Altman", "PERSON", "leads", "OpenAI", "ORGANIZATION", 0.97),
        ]

        triples = []
        for i, (s, st, r, o, ot, conf) in enumerate(mock_data):
            # Distribute across chunks
            chunk = chunks[i % len(chunks)] if chunks else None
            triples.append(Triple(
                subject=s, subject_type=st,
                relation=r,
                object=o, object_type=ot,
                confidence=conf,
                source_chunk_id=chunk.chunk_id if chunk else "mock",
                source_file=chunk.source_file if chunk else "mock",
            ))

        logger.info(f"  Mock extraction produced {len(triples)} triples")
        return triples
