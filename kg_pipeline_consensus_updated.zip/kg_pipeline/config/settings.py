"""
config/settings.py
==================
Central configuration for the Knowledge Graph Pipeline.
Edit this file to change API keys, models, and pipeline behaviour.
"""

import os
from pathlib import Path

# ─────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────
BASE_DIR       = Path(__file__).parent.parent
DATA_RAW       = BASE_DIR / "data" / "raw"
DATA_PROCESSED = BASE_DIR / "data" / "processed"
DATA_OUTPUT    = BASE_DIR / "data" / "output"

# Create dirs if they don't exist
for d in [DATA_RAW, DATA_PROCESSED, DATA_OUTPUT]:
    d.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────────────────────
# LLM SETTINGS
# ─────────────────────────────────────────────

# Provider: "anthropic" or "openai"
#LLM_PROVIDER = "anthropic"
LLM_PROVIDER = "gemini"

# Your API key — or set the env variable ANTHROPIC_API_KEY / OPENAI_API_KEY
#ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "YOUR_ANTHROPIC_API_KEY_HERE")
#OPENAI_API_KEY    = os.getenv("OPENAI_API_KEY",    "YOUR_OPENAI_API_KEY_HERE")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "YOUR_GEMINI_API_KEY_HERE")
# Model to use
# Anthropic options: "claude-opus-4-6", "claude-sonnet-4-6", "claude-haiku-4-5-20251001"
# OpenAI options:    "gpt-4o", "gpt-4o-mini"
#MODEL_NAME = "claude-opus-4-6"
MODEL_NAME = "gemini-2.5-flash"
# Max tokens the LLM will generate per extraction call
MAX_TOKENS = 2000

# Temperature — 0 = deterministic, good for structured extraction
TEMPERATURE = 0.0

# ─────────────────────────────────────────────
# DOCUMENT CHUNKING
# ─────────────────────────────────────────────

# Characters per chunk sent to the LLM
CHUNK_SIZE = 800

# Overlap between consecutive chunks (so entities at boundaries aren't missed)
CHUNK_OVERLAP = 100

# ─────────────────────────────────────────────
# ENTITY EXTRACTION
# ─────────────────────────────────────────────

# Entity types the LLM should look for
ENTITY_TYPES = [
    "PERSON",
    "ORGANIZATION",
    "LOCATION",
    "CONCEPT",
    "EVENT",
    "PRODUCT",
    "DATE",
    "TECHNOLOGY",
]

# Relation types to guide extraction (LLM can also discover new ones)
RELATION_TYPES = [
    "works_for",
    "located_in",
    "founded_by",
    "part_of",
    "created",
    "participated_in",
    "related_to",
    "caused_by",
    "used_in",
    "developed_by",
]

# ─────────────────────────────────────────────
# ENTITY RESOLUTION
# ─────────────────────────────────────────────

# Fuzzy string similarity threshold (0.0–1.0).
# Entities above this threshold are considered the same.
# Lower = more aggressive merging. Start at 0.85.
SIMILARITY_THRESHOLD = 0.85

# Use sentence-transformer embeddings for semantic similarity?
# More accurate but slower. Set False for fuzzy-only (fast).
USE_SEMANTIC_SIMILARITY = True

# Sentence transformer model for embeddings
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# ─────────────────────────────────────────────
# NEO4J SETTINGS
# ─────────────────────────────────────────────

# Set to False to skip Neo4j entirely (still exports to JSON/CSV)
NEO4J_ENABLED = True

NEO4J_URI      = os.getenv("NEO4J_URI",      "bolt://localhost:7687")
NEO4J_USER     = os.getenv("NEO4J_USER",     "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "password")

# ─────────────────────────────────────────────
# HALLUCINATION FILTERING / VERIFICATION  (legacy, single-LLM mode)
# ─────────────────────────────────────────────
# These settings only apply if you fall back to the legacy single-model
# HallucinationFilter (src/verification.py::HallucinationFilter), which is
# kept for backward compatibility / ablation studies. The pipeline's
# DEFAULT verification mechanism is now the Multi-LLM Consensus framework
# below (VerificationManager + ConsensusManager) which replaces per-triple
# lexical confidence with a cross-model Agreement Score.

# Minimum lexical grounding score (0-100, rapidfuzz partial_ratio) for a
# triple's subject & object to count as "found in the source chunk".
# Lower = more lenient (fewer false positives, more hallucinations slip
# through). 60 is a reasonable default for paraphrased entity mentions.
GROUNDING_THRESHOLD = 60.0

# What to do with triples that fail grounding/verification:
#   "flag"       -> keep them, but mark verified=False (visible in report)
#   "downweight" -> keep them, halve their confidence score
#   "drop"       -> remove them from the pipeline entirely
# "flag" is recommended for a thesis: it lets you report a hallucination
# rate without silently discarding data you may want to inspect.
HALLUCINATION_FILTER_MODE = "flag"

# If True, triples that pass the cheap lexical check are ALSO sent back to
# the LLM for a second, independent yes/no verification pass. This costs
# one extra API call per (already-grounded) triple, but catches subtler
# hallucinations — e.g. real entity names stitched into a relation that
# was never actually stated.
USE_LLM_VERIFICATION = False

# Triples below this confidence (after any down-weighting) are dropped
# regardless of HALLUCINATION_FILTER_MODE.
MIN_CONFIDENCE_THRESHOLD = 0.0

# ─────────────────────────────────────────────
# MULTI-LLM CONSENSUS VERIFICATION FRAMEWORK  (Stage 2 / 2.5, DEFAULT)
# ─────────────────────────────────────────────
# "Consensus-Based Knowledge Graph Construction from Unstructured Documents
# using Multiple Large Language Models for Hallucination Reduction"
#
# Three independent LLMs each build their own Knowledge Graph from the
# same chunks. Every triple generated by one model is then cross-verified
# by the OTHER two models against the source text. The fraction of
# verifying models that confirm a triple is its Agreement Score, which
# completely replaces the old single-model confidence score as the
# explainable "how much do we trust this fact" measure. See
# src/providers.py, src/verification.py::VerificationManager and
# src/consensus.py::ConsensusManager.

# Which models participate. Gemini is a hosted API call; Llama and Qwen
# run locally through Ollama. At least two must be enabled for cross
# verification to produce a meaningful (non-trivial) Agreement Score.
USE_GEMINI = True
USE_LLAMA = True
USE_QWEN = True

# Local Ollama server. No further code changes are required — the
# pipeline talks to this URL automatically as long as `ollama serve`
# is running and the models below have been pulled.
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")

# Ollama model tags (see: ollama pull <name>)
LLAMA_MODEL_NAME = os.getenv("LLAMA_MODEL_NAME", "llama3.1:8b")
QWEN_MODEL_NAME = os.getenv("QWEN_MODEL_NAME", "qwen3:8b")

# A triple is accepted into the final Consensus Knowledge Graph only if
#   (# verifying models that returned supported=true) / (# verifying models)
# is >= MIN_AGREEMENT_SCORE.
#   1.0  -> unanimous agreement required (strictest, highest precision)
#   0.5  -> majority-style agreement (at least one of two verifiers agrees)
#   0.0  -> accept everything (disables consensus filtering)
MIN_AGREEMENT_SCORE = 0.5

# Store the exact supporting sentence returned by each verifying model
# alongside the triple (Subject/Predicate/Object/Generator/Verification
# Results/Evidence/Agreement Score/Timestamp). Recommended "True" for a
# thesis — it makes every accepted/rejected triple fully explainable.
ENABLE_EVIDENCE_STORAGE = True

# Run Gemini / Llama / Qwen extraction concurrently (asyncio), and run
# cross-verification calls concurrently too, instead of sequential API
# calls. Strongly recommended — set False only for debugging.
ENABLE_ASYNC = True

# Maximum number of concurrent in-flight LLM calls (extraction or
# verification) per provider. Keeps local Ollama models (which share one
# GPU/CPU) from being overwhelmed while still parallelising the Gemini
# API calls.
CONSENSUS_MAX_CONCURRENCY = 4

# ─────────────────────────────────────────────
# EVALUATION
# ─────────────────────────────────────────────

# Path to a gold standard triples file for precision/recall evaluation.
# Format: one triple per line — "subject | relation | object"
# A sample file for the three demo documents (Einstein, Curie, OpenAI) is
# included at data/gold_standard.txt. Set to None to skip this evaluation,
# or point it at your own gold standard for a different corpus.
GOLD_STANDARD_PATH = BASE_DIR / "data" / "gold_standard.txt"

# Gold-standard matching is exact-string by default, which is strict for
# LLM output (e.g. "Nobel Prize in Physics" != "the Nobel Prize for Physics").
# When True, also computes a second precision/recall/F1 using fuzzy string
# matching (rapidfuzz), which is more representative of real KG accuracy.
GOLD_STANDARD_FUZZY_MATCH = True
GOLD_STANDARD_FUZZY_THRESHOLD = 85.0  # 0-100

# ─────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────

LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
