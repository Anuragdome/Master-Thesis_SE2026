"""
src/resolution.py
=================
Stage 3: Entity Resolution & Canonicalisation

Merges duplicate entities that refer to the same real-world thing.
For example: "Marie Curie", "M. Curie", "Madame Curie" → "Marie Curie"

Two strategies (configurable):
  1. Fuzzy string matching (fast, no model needed)
  2. Semantic embedding similarity (more accurate, requires sentence-transformers)
"""

import logging
from collections import defaultdict
from typing import List, Dict, Set, Tuple

from src.extraction import Triple

logger = logging.getLogger(__name__)


class EntityResolver:
    """
    Finds and merges duplicate entities across all extracted triples.

    After resolution, every triple's subject and object point to a
    canonical entity name. The entity index maps every alias to its
    canonical form.
    """

    def __init__(
        self,
        similarity_threshold: float = 0.85,
        use_semantic: bool = True,
        embedding_model: str = "all-MiniLM-L6-v2",
    ):
        self.threshold = similarity_threshold
        self.use_semantic = use_semantic
        self.embedding_model_name = embedding_model
        self._embedder = None

        # alias → canonical name
        self.canonical_map: Dict[str, str] = {}

        # canonical name → entity type
        self.entity_types: Dict[str, str] = {}

        # canonical name → set of all aliases seen
        self.aliases: Dict[str, Set[str]] = defaultdict(set)

    # ── Public API ────────────────────────────────────────────────────────

    def resolve(self, triples: List[Triple]) -> List[Triple]:
        """
        Main entry point.
        1. Collect all unique entity names from triples.
        2. Build a canonical map by clustering similar names.
        3. Rewrite all triples to use canonical names.
        4. Return the resolved triples.
        """
        logger.info("Building entity index...")
        entities = self._collect_entities(triples)
        logger.info(f"  Unique entity strings before resolution: {len(entities)}")

        logger.info("Clustering duplicate entities...")
        self._build_canonical_map(list(entities.keys()), entities)

        resolved_count = sum(1 for k, v in self.canonical_map.items() if k != v)
        logger.info(f"  Resolved {resolved_count} alias(es) to canonical forms")
        logger.info(f"  Canonical entities: {len(set(self.canonical_map.values()))}")

        logger.info("Rewriting triples with canonical names...")
        resolved_triples = self._rewrite_triples(triples)

        return resolved_triples

    def get_entity_summary(self) -> List[dict]:
        """Return a list of all canonical entities with their aliases and type."""
        seen: Set[str] = set()
        summary = []
        for canonical in sorted(set(self.canonical_map.values())):
            if canonical in seen:
                continue
            seen.add(canonical)
            summary.append({
                "name": canonical,
                "type": self.entity_types.get(canonical, "CONCEPT"),
                "aliases": sorted(self.aliases.get(canonical, {canonical})),
            })
        return summary

    # ── Private helpers ───────────────────────────────────────────────────

    def _collect_entities(self, triples: List[Triple]) -> Dict[str, str]:
        """
        Returns a dict of {entity_name: entity_type} for all
        subjects and objects in the triple list.
        """
        entities: Dict[str, str] = {}
        for t in triples:
            if t.subject:
                entities[t.subject] = t.subject_type
            if t.object:
                entities[t.object] = t.object_type
        return entities

    def _build_canonical_map(
        self, names: List[str], types: Dict[str, str]
    ) -> None:
        """
        Group entity names into clusters. The longest (most complete) name
        in each cluster becomes the canonical form.
        """
        # Start: every entity is its own canonical
        for name in names:
            self.canonical_map[name] = name
            self.entity_types[name] = types.get(name, "CONCEPT")
            self.aliases[name].add(name)

        # Find pairs that should be merged
        pairs_to_merge = self._find_similar_pairs(names)

        # Union-Find merge
        for a, b in pairs_to_merge:
            self._merge(a, b, types)

    def _find_similar_pairs(self, names: List[str]) -> List[Tuple[str, str]]:
        """
        Find pairs of entity names that are similar enough to merge.
        Uses fuzzy matching, and optionally semantic similarity.
        """
        pairs = []
        fuzzy_pairs = self._fuzzy_pairs(names)
        pairs.extend(fuzzy_pairs)

        if self.use_semantic and len(names) > 1:
            semantic_pairs = self._semantic_pairs(names)
            # Add semantic pairs not already in fuzzy pairs
            existing = {(a, b) for a, b in pairs}
            for a, b in semantic_pairs:
                if (a, b) not in existing and (b, a) not in existing:
                    pairs.append((a, b))

        return pairs

    def _fuzzy_pairs(self, names: List[str]) -> List[Tuple[str, str]]:
        """Find pairs with high fuzzy string similarity."""
        try:
            from rapidfuzz import fuzz
        except ImportError:
            logger.warning("rapidfuzz not installed — skipping fuzzy matching")
            return []

        pairs = []
        n = len(names)
        for i in range(n):
            for j in range(i + 1, n):
                a, b = names[i], names[j]
                # Skip if types clearly differ (PERSON vs LOCATION)
                score = fuzz.token_sort_ratio(a.lower(), b.lower()) / 100.0
                if score >= self.threshold:
                    pairs.append((a, b))
        return pairs

    def _semantic_pairs(self, names: List[str]) -> List[Tuple[str, str]]:
        """Find pairs with high semantic embedding cosine similarity."""
        try:
            from sentence_transformers import SentenceTransformer
            import numpy as np
        except ImportError:
            logger.warning("sentence-transformers not installed — skipping semantic similarity")
            return []

        if self._embedder is None:
            logger.info(f"  Loading embedding model: {self.embedding_model_name}")
            self._embedder = SentenceTransformer(self.embedding_model_name)

        embeddings = self._embedder.encode(names, convert_to_numpy=True, show_progress_bar=False)

        # Cosine similarity matrix
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms[norms == 0] = 1
        normalized = embeddings / norms
        similarity_matrix = normalized @ normalized.T

        pairs = []
        n = len(names)
        for i in range(n):
            for j in range(i + 1, n):
                if similarity_matrix[i, j] >= self.threshold:
                    pairs.append((names[i], names[j]))
        return pairs

    def _merge(self, a: str, b: str, types: Dict[str, str]) -> None:
        """
        Merge two entities. The canonical form is chosen as:
        - Whichever is already canonical for more names, or
        - The longer name (more complete form).
        """
        canon_a = self.canonical_map[a]
        canon_b = self.canonical_map[b]

        if canon_a == canon_b:
            return  # Already merged

        # Choose the better canonical: prefer longer name
        if len(canon_a) >= len(canon_b):
            winner, loser = canon_a, canon_b
        else:
            winner, loser = canon_b, canon_a

        # Remap everything pointing to loser → winner
        for name in list(self.canonical_map.keys()):
            if self.canonical_map[name] == loser:
                self.canonical_map[name] = winner
                self.aliases[winner].add(name)
                self.aliases[loser].discard(name)

        # Merge type (keep winner's type)
        if winner not in self.entity_types:
            self.entity_types[winner] = types.get(loser, "CONCEPT")

    def _rewrite_triples(self, triples: List[Triple]) -> List[Triple]:
        """Replace every entity name with its canonical form."""
        rewritten = []
        for t in triples:
            new_subject = self.canonical_map.get(t.subject, t.subject)
            new_object = self.canonical_map.get(t.object, t.object)

            rewritten.append(Triple(
                subject=new_subject,
                subject_type=self.entity_types.get(new_subject, t.subject_type),
                relation=t.relation,
                object=new_object,
                object_type=self.entity_types.get(new_object, t.object_type),
                confidence=t.confidence,
                source_chunk_id=t.source_chunk_id,
                source_file=t.source_file,
            ))
        return rewritten
