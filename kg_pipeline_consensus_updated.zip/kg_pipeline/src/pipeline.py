"""
src/pipeline.py
===============
Pipeline Orchestrator

Two modes, chosen automatically based on config/settings.py:

  CONSENSUS MODE (default; used whenever >=2 LLM providers are configured
  and reachable — e.g. Gemini + Llama via Ollama, or Llama + Qwen with no
  Gemini key at all):

    1. Document ingestion
    2. Independent extraction (Gemini / Llama / Qwen — Step 1)
    3. Entity resolution (shared across all three graphs)
    4. Triple alignment (Step 2)
    5. Cross verification + Agreement Score (Step 3-5)
    6. Consensus rule + Consensus Knowledge Graph (Step 6-7)
    7. Graph construction (Neo4j + exports, with full metadata — Step 8)
    8. Evaluation (per-model / consensus / gold-standard / improvement — Step 9)

  LEGACY MODE (automatic fallback — preserves the original single-model
  pipeline byte-for-byte in behaviour): used when fewer than 2 providers
  are configured (e.g. no API key and Ollama not running), so the project
  keeps working exactly as before out of the box.

Import and call Pipeline.run() or use run_pipeline.py as the entry point.
Pipeline.run() is a synchronous wrapper around the async implementation
(Step 10: extraction and verification run concurrently via asyncio under
the hood; run_pipeline.py / app.py do not need to know about asyncio).
"""

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class Pipeline:
    """
    End-to-end knowledge graph pipeline.

    Usage:
        from src.pipeline import Pipeline
        pipeline = Pipeline()
        results = pipeline.run()
    """

    def __init__(self, config_module=None):
        """
        Load settings from config/settings.py (or pass a custom module).
        """
        if config_module is None:
            import config.settings as config_module
        self.cfg = config_module

    def run(self, input_dir: Optional[Path] = None) -> dict:
        """
        Execute the full pipeline and return evaluation results.
        Synchronous entry point (used by run_pipeline.py / app.py) — wraps
        the async implementation so callers never have to deal with
        asyncio directly.
        """
        return asyncio.run(self.run_async(input_dir))

    async def run_async(self, input_dir: Optional[Path] = None) -> dict:
        start_time = time.time()

        logger.info("=" * 55)
        logger.info("  KNOWLEDGE GRAPH PIPELINE")
        logger.info("=" * 55)

        input_dir = input_dir or self.cfg.DATA_RAW

        # ── Stage 1: Ingestion ────────────────────────────────────────────
        logger.info("\n[ STAGE 1 ] Document Ingestion")
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester(
            chunk_size=self.cfg.CHUNK_SIZE,
            chunk_overlap=self.cfg.CHUNK_OVERLAP,
        )
        chunks = ingester.ingest_directory(input_dir)

        if not chunks:
            logger.error("No chunks produced. Aborting.")
            return {}

        self._save_intermediate(
            [{"chunk_id": c.chunk_id, "source": c.source_file, "text": c.text} for c in chunks],
            "chunks.json"
        )

        # ── Decide mode: Multi-LLM Consensus vs legacy single-model ───────
        from src.providers import build_providers_from_settings
        providers = build_providers_from_settings(self.cfg)

        if len(providers) >= 2:
            return await self._run_consensus(chunks, providers, start_time)
        else:
            logger.warning(
                f"Only {len(providers)} LLM provider(s) configured/available "
                f"(need >= 2 for Multi-LLM Consensus Verification). Falling back "
                f"to the legacy single-model pipeline. Enable USE_GEMINI / "
                f"USE_LLAMA / USE_QWEN in config/settings.py and make sure "
                f"'ollama serve' is running to use the consensus framework."
            )
            return await self._run_legacy(chunks, providers, start_time)

    # ══════════════════════════════════════════════════════════════════
    #  CONSENSUS MODE — Steps 1-11
    # ══════════════════════════════════════════════════════════════════

    async def _run_consensus(self, chunks, providers: dict, start_time: float) -> dict:
        cfg = self.cfg

        # ── Stage 2: Independent Extraction (Step 1) ───────────────────
        logger.info(f"\n[ STAGE 2 ] Independent Multi-LLM Extraction ({', '.join(providers)})")
        from src.extraction import MultiLLMExtractor
        extractor = MultiLLMExtractor(providers)
        triples_by_model = await extractor.extract_all(chunks)

        extraction_stats = {
            name: len(triples) for name, triples in triples_by_model.items()
        }
        self._save_intermediate(
            {name: [t.to_dict() for t in triples] for name, triples in triples_by_model.items()},
            "raw_triples_by_model.json"
        )
        all_raw = [t for triples in triples_by_model.values() for t in triples]
        self._save_intermediate([t.to_dict() for t in all_raw], "raw_triples.json")

        # ── Stage 3: Entity Resolution (shared across all 3 graphs) ─────
        logger.info("\n[ STAGE 3 ] Entity Resolution")
        from src.resolution import EntityResolver
        resolver = EntityResolver(
            similarity_threshold=cfg.SIMILARITY_THRESHOLD,
            use_semantic=cfg.USE_SEMANTIC_SIMILARITY,
            embedding_model=cfg.EMBEDDING_MODEL,
        )
        # Resolve against the union of all independently-generated triples
        # so subjects/objects share one canonical map before verification.
        resolver.resolve(all_raw)
        self._save_intermediate(resolver.get_entity_summary(), "entities.json")

        # ── Stage 3.5: Triple Alignment (Step 2) ────────────────────────
        logger.info("\n[ STAGE 3.5 ] Triple Alignment")
        from src.consensus import TripleAligner
        aligner = TripleAligner(resolver)
        for name in triples_by_model:
            triples_by_model[name] = aligner.align(triples_by_model[name])

        # ── Stage 4: Cross Verification + Agreement Score (Step 3-5) ────
        logger.info(
            f"\n[ STAGE 4 ] Cross Verification "
            f"(evidence_storage={cfg.ENABLE_EVIDENCE_STORAGE})"
        )
        from src.verification import VerificationManager
        verification_manager = VerificationManager(
            providers=providers,
            chunks=chunks,
            enable_evidence_storage=cfg.ENABLE_EVIDENCE_STORAGE,
        )
        all_verified = await verification_manager.cross_verify(triples_by_model)
        verification_stats = verification_manager.last_stats

        self._save_intermediate([t.to_dict() for t in all_verified], "verified_triples.json")

        # ── Stage 5: Consensus Rule + Consensus Knowledge Graph (Step 6-7)
        logger.info(f"\n[ STAGE 5 ] Consensus Selection (MIN_AGREEMENT_SCORE={cfg.MIN_AGREEMENT_SCORE})")
        from src.consensus import ConsensusManager
        consensus_manager = ConsensusManager(min_agreement_score=cfg.MIN_AGREEMENT_SCORE)
        accepted, rejected = consensus_manager.select_consensus(all_verified)

        # Keep `confidence` mirroring the new Agreement Score so every
        # existing consumer of Triple.confidence (CSV/Cypher/legacy
        # notebooks) automatically reflects the new trust metric (Step 5:
        # "Completely remove the old confidence score. Replace it with
        # Agreement Score.").
        for t in accepted + rejected:
            t.confidence = t.agreement_score if t.agreement_score is not None else t.confidence

        self._save_intermediate([t.to_dict() for t in accepted], "consensus_triples.json")

        # ── Stage 6: Graph Construction — Consensus Knowledge Graph ─────
        logger.info("\n[ STAGE 6 ] Consensus Knowledge Graph Construction")
        from src.graph_builder import GraphBuilder
        builder = GraphBuilder(
            neo4j_enabled=cfg.NEO4J_ENABLED,
            neo4j_uri=cfg.NEO4J_URI,
            neo4j_user=cfg.NEO4J_USER,
            neo4j_password=cfg.NEO4J_PASSWORD,
            output_dir=cfg.DATA_OUTPUT,
        )
        graph_stats = builder.build(accepted, resolver)

        # ── Stage 7: Evaluation (Step 9) ─────────────────────────────────
        logger.info("\n[ STAGE 7 ] Evaluation")
        from src.evaluation import EvaluationManager
        evaluator = EvaluationManager(
            output_dir=cfg.DATA_OUTPUT,
            gold_standard_path=cfg.GOLD_STANDARD_PATH,
            fuzzy_match=cfg.GOLD_STANDARD_FUZZY_MATCH,
            fuzzy_threshold=cfg.GOLD_STANDARD_FUZZY_THRESHOLD,
        )
        results = evaluator.evaluate_consensus(
            triples_by_model=triples_by_model,
            all_verified_triples=all_verified,
            accepted_triples=accepted,
            rejected_triples=rejected,
            resolved_triples=accepted,
            resolver=resolver,
            graph_stats=graph_stats,
            extraction_stats=extraction_stats,
            verification_stats=verification_stats,
            consensus_stats=consensus_manager.last_stats,
        )
        results["pipeline_mode"] = "consensus"
        results["providers_used"] = list(providers.keys())
        # Actual configured model identifier behind each provider key (e.g.
        # {"gemini": "gemini-2.5-flash", "llama": "llama3.1:8b"}), read
        # straight off the BaseLLM instances actually used — so the UI can
        # label metrics with the real model names instead of generic
        # "Model 1/2/3" placeholders, and never gets out of sync with
        # config/settings.py or Streamlit sidebar overrides.
        results["provider_model_names"] = {
            name: provider.model_name for name, provider in providers.items()
        }

        elapsed = time.time() - start_time
        logger.info(f"\nConsensus pipeline completed in {elapsed:.1f}s")
        logger.info(f"Outputs saved to: {cfg.DATA_OUTPUT}")
        if cfg.NEO4J_ENABLED:
            logger.info("Neo4j browser: http://localhost:7474")
            logger.info("  Query: MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 50")

        return results

    # ══════════════════════════════════════════════════════════════════
    #  LEGACY MODE — single-model pipeline, kept for backward
    #  compatibility when fewer than 2 LLM providers are configured.
    # ══════════════════════════════════════════════════════════════════

    async def _run_legacy(self, chunks, providers: dict, start_time: float) -> dict:
        cfg = self.cfg

        logger.info(f"\n[ STAGE 2 ] LLM Extraction (legacy single-model)")

        if len(providers) == 1:
            # Exactly one real provider available — extract with it, but
            # there's no second/third model to cross-verify against, so
            # fall back to the original lexical/LLM hallucination filter
            # instead of a (meaningless, single-verifier) Agreement Score.
            name, provider = next(iter(providers.items()))
            logger.info(f"  Using single available provider: {name}")
            raw_triples = await self._extract_single_provider(name, provider, chunks)
        else:
            logger.warning("No real API key / local model configured. Using mock extraction for demo.")
            raw_triples = self._mock_extraction(chunks)

        self._save_intermediate([t.to_dict() for t in raw_triples], "raw_triples.json")

        # ── Stage 2.5: legacy Hallucination Filtering ──────────────────
        logger.info(
            f"\n[ STAGE 2.5 ] Hallucination Filtering "
            f"(mode='{cfg.HALLUCINATION_FILTER_MODE}', "
            f"llm_verification={cfg.USE_LLM_VERIFICATION})"
        )
        from src.verification import HallucinationFilter
        hallucination_filter = HallucinationFilter(
            chunks=chunks,
            grounding_threshold=cfg.GROUNDING_THRESHOLD,
            mode=cfg.HALLUCINATION_FILTER_MODE,
            use_llm_verification=False,  # legacy sync LLM verify not wired to async providers
            extractor=None,
            min_confidence=cfg.MIN_CONFIDENCE_THRESHOLD,
        )
        raw_triples = hallucination_filter.filter(raw_triples)
        verification_stats = hallucination_filter.last_stats

        self._save_intermediate([t.to_dict() for t in raw_triples], "verified_triples.json")

        # ── Stage 3: Entity Resolution ──────────────────────────────────
        logger.info("\n[ STAGE 3 ] Entity Resolution")
        from src.resolution import EntityResolver
        resolver = EntityResolver(
            similarity_threshold=cfg.SIMILARITY_THRESHOLD,
            use_semantic=cfg.USE_SEMANTIC_SIMILARITY,
            embedding_model=cfg.EMBEDDING_MODEL,
        )
        resolved_triples = resolver.resolve(raw_triples)
        self._save_intermediate(resolver.get_entity_summary(), "entities.json")

        # ── Stage 4: Graph Construction ─────────────────────────────────
        logger.info("\n[ STAGE 4 ] Graph Construction")
        from src.graph_builder import GraphBuilder
        builder = GraphBuilder(
            neo4j_enabled=cfg.NEO4J_ENABLED,
            neo4j_uri=cfg.NEO4J_URI,
            neo4j_user=cfg.NEO4J_USER,
            neo4j_password=cfg.NEO4J_PASSWORD,
            output_dir=cfg.DATA_OUTPUT,
        )
        graph_stats = builder.build(resolved_triples, resolver)

        # ── Stage 5: Evaluation ─────────────────────────────────────────
        logger.info("\n[ STAGE 5 ] Evaluation")
        from src.evaluation import Evaluator
        evaluator = Evaluator(
            output_dir=cfg.DATA_OUTPUT,
            gold_standard_path=cfg.GOLD_STANDARD_PATH,
            fuzzy_match=cfg.GOLD_STANDARD_FUZZY_MATCH,
            fuzzy_threshold=cfg.GOLD_STANDARD_FUZZY_THRESHOLD,
        )
        results = evaluator.evaluate(
            raw_triples=raw_triples,
            resolved_triples=resolved_triples,
            resolver=resolver,
            graph_stats=graph_stats,
            verification_stats=verification_stats,
        )
        results["pipeline_mode"] = "legacy"
        results["providers_used"] = list(providers.keys())
        # See the matching comment in _run_consensus — same idea, so the
        # single-model (or mock, if providers is empty) legacy path can
        # still show a real model name in the UI rather than a placeholder.
        results["provider_model_names"] = {
            name: provider.model_name for name, provider in providers.items()
        }

        elapsed = time.time() - start_time
        logger.info(f"\nPipeline completed in {elapsed:.1f}s")
        logger.info(f"Outputs saved to: {cfg.DATA_OUTPUT}")
        if cfg.NEO4J_ENABLED:
            logger.info("Neo4j browser: http://localhost:7474")
            logger.info("  Query: MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 50")

        return results

    async def _extract_single_provider(self, name, provider, chunks) -> list:
        from src.extraction import parse_triples_json

        async def run_chunk(chunk):
            try:
                raw = await provider.extract_triples_raw(chunk.text)
                return parse_triples_json(raw, chunk, generator_model=name)
            except Exception as e:
                logger.error(f"  [{name}] extraction failed on {chunk.chunk_id}: {e}")
                return []

        results = await asyncio.gather(*(run_chunk(c) for c in chunks))
        triples = [t for sub in results for t in sub]
        logger.info(f"  [{name}] extracted {len(triples)} triple(s)")
        return triples

    # ── Helpers ───────────────────────────────────────────────────────────

    def _save_intermediate(self, data, filename: str) -> None:
        path = self.cfg.DATA_PROCESSED / filename
        path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
        logger.debug(f"Saved intermediate: {path}")

    def _mock_extraction(self, chunks) -> list:
        """
        Returns realistic mock triples when no LLM provider is available at
        all. Useful for testing the rest of the pipeline without spending
        API credits or running Ollama.

        Each triple is assigned to a chunk from the document it's actually
        about (matched via `topic`), so downstream hallucination filtering
        behaves the same way it would on real LLM output. A couple of
        intentionally-wrong triples are included (marked "hallucination_demo")
        purely so the filter has something real to catch when you run the
        pipeline without any provider configured.
        """
        from src.extraction import Triple

        mock_data = [
            # (subject, subj_type, relation, object, obj_type, confidence, topic)
            ("Marie Curie", "PERSON", "won", "Nobel Prize in Physics", "CONCEPT", 0.99, "marie_curie"),
            ("Marie Curie", "PERSON", "won", "Nobel Prize in Chemistry", "CONCEPT", 0.99, "marie_curie"),
            ("Marie Curie", "PERSON", "worked_at", "University of Paris", "ORGANIZATION", 0.97, "marie_curie"),
            ("Marie Curie", "PERSON", "born_in", "Warsaw", "LOCATION", 0.98, "marie_curie"),
            ("Marie Curie", "PERSON", "married", "Pierre Curie", "PERSON", 0.99, "marie_curie"),
            ("Pierre Curie", "PERSON", "worked_at", "University of Paris", "ORGANIZATION", 0.95, "marie_curie"),
            ("Marie Curie", "PERSON", "discovered", "Polonium", "CONCEPT", 0.99, "marie_curie"),
            ("Marie Curie", "PERSON", "discovered", "Radium", "CONCEPT", 0.99, "marie_curie"),
            ("M. Curie", "PERSON", "founded", "Curie Institute", "ORGANIZATION", 0.92, "marie_curie"),
            ("Albert Einstein", "PERSON", "developed", "Theory of Relativity", "CONCEPT", 0.99, "albert_einstein"),
            ("Albert Einstein", "PERSON", "won", "Nobel Prize in Physics", "CONCEPT", 0.99, "albert_einstein"),
            ("Albert Einstein", "PERSON", "worked_at", "Institute for Advanced Study", "ORGANIZATION", 0.97, "albert_einstein"),
            ("Einstein", "PERSON", "born_in", "Germany", "LOCATION", 0.98, "albert_einstein"),
            ("Albert Einstein", "PERSON", "collaborated_with", "Niels Bohr", "PERSON", 0.95, "albert_einstein"),
            ("Albert Einstein", "PERSON", "taught_at", "ETH Zurich", "ORGANIZATION", 0.96, "albert_einstein"),
            ("OpenAI", "ORGANIZATION", "founded_by", "Sam Altman", "PERSON", 0.99, "openai"),
            ("OpenAI", "ORGANIZATION", "founded_by", "Elon Musk", "PERSON", 0.98, "openai"),
            ("OpenAI", "ORGANIZATION", "located_in", "San Francisco", "LOCATION", 0.99, "openai"),
            ("OpenAI", "ORGANIZATION", "developed", "GPT-4", "TECHNOLOGY", 0.99, "openai"),
            ("OpenAI", "ORGANIZATION", "developed", "ChatGPT", "TECHNOLOGY", 0.99, "openai"),
            ("Microsoft", "ORGANIZATION", "invested_in", "OpenAI", "ORGANIZATION", 0.98, "openai"),
            ("Sam Altman", "PERSON", "leads", "OpenAI", "ORGANIZATION", 0.97, "openai"),
            # Deliberately fabricated facts, not present in any source doc —
            # demonstrates the hallucination filter catching real errors.
            ("Marie Curie", "PERSON", "won", "Turing Award", "CONCEPT", 0.90, "hallucination_demo"),
            ("OpenAI", "ORGANIZATION", "acquired", "DeepMind", "ORGANIZATION", 0.85, "hallucination_demo"),
        ]

        chunks_by_topic: dict = {}
        for c in chunks:
            topic = Path(c.source_file).stem
            chunks_by_topic.setdefault(topic, []).append(c)

        triples = []
        for s, st, r, o, ot, conf, topic in mock_data:
            candidates = chunks_by_topic.get(topic)
            if candidates:
                chunk = candidates[0]
            else:
                # "hallucination_demo" topic (or unknown doc): pin to any
                # real chunk so it still has a source_chunk_id, but its
                # content deliberately won't mention these entities.
                chunk = chunks[0] if chunks else None

            triples.append(Triple(
                subject=s, subject_type=st,
                relation=r,
                object=o, object_type=ot,
                confidence=conf,
                source_chunk_id=chunk.chunk_id if chunk else "mock",
                source_file=chunk.source_file if chunk else "mock",
                generator_model="mock",
            ))

        logger.info(f"  Mock extraction produced {len(triples)} triples")
        return triples
