"""
src/extraction.py
=================
Stage 2: LLM-Based Entity & Relation Extraction

Sends each document chunk to the LLM and parses structured
(subject, relation, object) triples from the response.

Supports both Anthropic Claude and OpenAI GPT models.
"""

import json
import logging
import time
from typing import List, Optional
from dataclasses import dataclass, field

from src.ingestion import DocumentChunk

logger = logging.getLogger(__name__)


@dataclass
class Triple:
    """
    A knowledge triple: (subject, relation, object)
    e.g. ("Marie Curie", "won", "Nobel Prize in Physics")
    """
    subject: str
    subject_type: str
    relation: str
    object: str
    object_type: str
    confidence: float = 1.0
    source_chunk_id: str = ""
    source_file: str = ""

    def to_dict(self) -> dict:
        return {
            "subject": self.subject,
            "subject_type": self.subject_type,
            "relation": self.relation,
            "object": self.object,
            "object_type": self.object_type,
            "confidence": self.confidence,
            "source_chunk_id": self.source_chunk_id,
            "source_file": self.source_file,
        }

    def __str__(self) -> str:
        return f"({self.subject}) --[{self.relation}]--> ({self.object})"


class LLMExtractor:
    """
    Sends document chunks to an LLM and extracts structured triples.

    The LLM is prompted with few-shot examples and a JSON schema,
    and its output is parsed, validated, and returned as Triple objects.
    """

    EXTRACTION_SYSTEM_PROMPT = """You are an expert knowledge graph builder.
Your task is to extract entities and relationships from text and return them as structured JSON.

Rules:
1. Extract only EXPLICIT facts stated in the text. Do not infer or add external knowledge.
2. Each triple must have a subject, a relation verb, and an object.
3. Entity types must be one of: PERSON, ORGANIZATION, LOCATION, CONCEPT, EVENT, PRODUCT, DATE, TECHNOLOGY
4. Relations should be short verb phrases in snake_case (e.g. works_for, located_in, founded_by).
5. Names should be in canonical form (full names preferred).
6. Return ONLY valid JSON. No explanation, no markdown, no preamble.

Output format:
{
  "triples": [
    {
      "subject": "entity name",
      "subject_type": "ENTITY_TYPE",
      "relation": "relation_verb",
      "object": "entity name",
      "object_type": "ENTITY_TYPE",
      "confidence": 0.95
    }
  ]
}

If no clear entities or relations are found, return: {"triples": []}"""

    FEW_SHOT_EXAMPLE = """
Example:
Text: "Marie Curie won the Nobel Prize in Physics in 1903. She worked at the University of Paris."

Output:
{
  "triples": [
    {"subject": "Marie Curie", "subject_type": "PERSON", "relation": "won", "object": "Nobel Prize in Physics", "object_type": "CONCEPT", "confidence": 0.99},
    {"subject": "Nobel Prize in Physics", "subject_type": "CONCEPT", "relation": "awarded_in", "object": "1903", "object_type": "DATE", "confidence": 0.99},
    {"subject": "Marie Curie", "subject_type": "PERSON", "relation": "worked_at", "object": "University of Paris", "object_type": "ORGANIZATION", "confidence": 0.97}
  ]
}
"""

    def __init__(
        self,
        provider: str = "anthropic",
        model_name: str = "claude-opus-4-6",
        api_key: str = "",
        max_tokens: int = 2000,
        temperature: float = 0.0,
    ):
        self.provider = provider
        self.model_name = model_name
        self.api_key = api_key
        self.max_tokens = max_tokens
        self.temperature = temperature
        self._client = None

    def _get_client(self):
        """Lazy-initialise the API client."""
        if self._client is not None:
            return self._client

        if self.provider == "anthropic":
            import anthropic
            self._client = anthropic.Anthropic(api_key=self.api_key)
        elif self.provider == "openai":
            from openai import OpenAI
            self._client = OpenAI(api_key=self.api_key)

        elif self.provider == "gemini":
            from google import genai
            self._client = genai.Client(api_key=self.api_key)

        else:
            raise ValueError(f"Unknown LLM provider: {self.provider}")

        return self._client

    def extract_from_chunks(
        self, chunks: List[DocumentChunk], delay_seconds: float = 0.5
    ) -> List[Triple]:
        """
        Extract triples from a list of document chunks.
        Adds a small delay between API calls to avoid rate limits.
        """
        all_triples: List[Triple] = []
        total = len(chunks)

        for i, chunk in enumerate(chunks):
            logger.info(f"  Extracting chunk {i+1}/{total}: {chunk.chunk_id}")
            try:
                triples = self.extract_from_chunk(chunk)
                all_triples.extend(triples)
                logger.debug(f"    → {len(triples)} triple(s) extracted")
            except Exception as e:
                logger.error(f"    → Extraction failed: {e}")

            # Avoid hammering the API
            if i < total - 1:
                time.sleep(delay_seconds)

        logger.info(f"Total triples extracted: {len(all_triples)}")
        return all_triples

    def extract_from_chunk(self, chunk: DocumentChunk) -> List[Triple]:
        """Extract triples from a single chunk."""
        prompt = self._build_prompt(chunk.text)
        raw_response = self._call_llm(prompt)
        triples = self._parse_response(raw_response, chunk)
        return triples

    def extract_from_text(self, text: str, source: str = "manual") -> List[Triple]:
        """Convenience method: extract from raw text."""
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester()
        chunks = ingester.ingest_text(text, source)
        return self.extract_from_chunks(chunks)

    # ── Private helpers ───────────────────────────────────────────────────

    def _build_prompt(self, text: str) -> str:
        return f"""{self.FEW_SHOT_EXAMPLE}

Now extract all entities and relationships from the following text:

Text: \"\"\"{text}\"\"\"

Return only valid JSON."""

    def _call_llm(self, prompt: str) -> str:
        client = self._get_client()

        if self.provider == "anthropic":
            response = client.messages.create(
                model=self.model_name,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                system=self.EXTRACTION_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text

        elif self.provider == "openai":
            response = client.chat.completions.create(
                model=self.model_name,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                messages=[
                    {"role": "system", "content": self.EXTRACTION_SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                response_format={"type": "json_object"},
            )
            return response.choices[0].message.content
        
        elif self.provider == "gemini":
            full_prompt = self.EXTRACTION_SYSTEM_PROMPT + "\n\n" + prompt

            response = client.models.generate_content(
                model=self.model_name,
                contents=full_prompt,
            )

            return response.text

    def _parse_response(self, raw: str, chunk: DocumentChunk) -> List[Triple]:
        """Parse the LLM JSON response into Triple objects."""
        # Strip markdown code fences if the LLM included them
        raw = raw.strip()
        if raw.startswith("```"):
            lines = raw.split("\n")
            raw = "\n".join(lines[1:-1]) if lines[-1] == "```" else "\n".join(lines[1:])

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            logger.warning(f"JSON parse error: {e}. Raw response: {raw[:200]}")
            return []

        triples = []
        for item in data.get("triples", []):
            try:
                t = Triple(
                    subject=str(item.get("subject", "")).strip(),
                    subject_type=str(item.get("subject_type", "CONCEPT")).upper(),
                    relation=str(item.get("relation", "related_to")).strip().lower().replace(" ", "_"),
                    object=str(item.get("object", "")).strip(),
                    object_type=str(item.get("object_type", "CONCEPT")).upper(),
                    confidence=float(item.get("confidence", 1.0)),
                    source_chunk_id=chunk.chunk_id,
                    source_file=chunk.source_file,
                )
                # Skip triples with empty subject or object
                if t.subject and t.object:
                    triples.append(t)
            except Exception as e:
                logger.warning(f"Skipping malformed triple {item}: {e}")

        return triples
