"""
tests/test_pipeline.py
======================
Unit tests for each stage of the KG pipeline.

Run with:
    pytest tests/ -v
"""

import pytest
from pathlib import Path
import tempfile
import sys
import os

# Ensure the project root is on the path
sys.path.insert(0, str(Path(__file__).parent.parent))


# ── Stage 1: Ingestion ────────────────────────────────────────────────────────

class TestIngestion:

    def test_ingest_txt_file(self):
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester(chunk_size=200, chunk_overlap=20)

        with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", delete=False) as f:
            f.write("Marie Curie won the Nobel Prize in Physics. " * 10)
            path = Path(f.name)

        try:
            chunks = ingester._process_file(path)
            assert len(chunks) > 0
            assert all(c.text for c in chunks)
            assert all(c.source_file == path.name for c in chunks)
        finally:
            path.unlink()

    def test_chunk_overlap(self):
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester(chunk_size=100, chunk_overlap=20)
        text = "A" * 300
        chunks = ingester._chunk_text(text, "test")
        assert len(chunks) > 1
        # Verify overlap: end of chunk n overlaps with start of chunk n+1
        for i in range(len(chunks) - 1):
            # Some overlap expected
            assert len(chunks[i].text) >= 80

    def test_clean_text(self):
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester()
        dirty = "Hello\r\n\r\n\r\nWorld   extra   spaces"
        clean = ingester._clean_text(dirty)
        assert "\r" not in clean
        assert "\n\n\n" not in clean
        assert "   " not in clean

    def test_ingest_directory_generates_samples(self):
        from src.ingestion import DocumentIngester
        ingester = DocumentIngester()
        with tempfile.TemporaryDirectory() as tmpdir:
            chunks = ingester.ingest_directory(Path(tmpdir))
            assert len(chunks) > 0  # Sample documents generated


# ── Stage 2: Extraction ───────────────────────────────────────────────────────

class TestExtraction:

    def test_parse_valid_json(self):
        from src.ingestion import DocumentChunk
        from src.extraction import LLMExtractor

        extractor = LLMExtractor()
        chunk = DocumentChunk(
            chunk_id="test_0001", source_file="test.txt", chunk_index=0, text="test"
        )
        raw = '{"triples": [{"subject": "Marie Curie", "subject_type": "PERSON", "relation": "won", "object": "Nobel Prize", "object_type": "CONCEPT", "confidence": 0.99}]}'
        triples = extractor._parse_response(raw, chunk)
        assert len(triples) == 1
        assert triples[0].subject == "Marie Curie"
        assert triples[0].relation == "won"
        assert triples[0].object == "Nobel Prize"

    def test_parse_handles_markdown_fences(self):
        from src.ingestion import DocumentChunk
        from src.extraction import LLMExtractor
        extractor = LLMExtractor()
        chunk = DocumentChunk(
            chunk_id="test_0001", source_file="test.txt", chunk_index=0, text="test"
        )
        raw = '```json\n{"triples": []}\n```'
        triples = extractor._parse_response(raw, chunk)
        assert triples == []

    def test_parse_invalid_json_returns_empty(self):
        from src.ingestion import DocumentChunk
        from src.extraction import LLMExtractor
        extractor = LLMExtractor()
        chunk = DocumentChunk(
            chunk_id="test_0001", source_file="test.txt", chunk_index=0, text="test"
        )
        triples = extractor._parse_response("not json at all", chunk)
        assert triples == []

    def test_skips_triples_with_empty_fields(self):
        from src.ingestion import DocumentChunk
        from src.extraction import LLMExtractor
        extractor = LLMExtractor()
        chunk = DocumentChunk(
            chunk_id="test_0001", source_file="test.txt", chunk_index=0, text="test"
        )
        raw = '{"triples": [{"subject": "", "subject_type": "PERSON", "relation": "won", "object": "Nobel Prize", "object_type": "CONCEPT", "confidence": 0.9}]}'
        triples = extractor._parse_response(raw, chunk)
        assert len(triples) == 0


# ── Stage 3: Entity Resolution ────────────────────────────────────────────────

class TestResolution:

    def _make_triples(self, data):
        from src.extraction import Triple
        return [
            Triple(subject=s, subject_type=st, relation=r, object=o, object_type=ot)
            for s, st, r, o, ot in data
        ]

    def test_exact_duplicates_merged(self):
        from src.resolution import EntityResolver
        resolver = EntityResolver(similarity_threshold=0.85, use_semantic=False)
        triples = self._make_triples([
            ("Marie Curie", "PERSON", "won", "Nobel Prize", "CONCEPT"),
            ("Marie Curie", "PERSON", "born_in", "Warsaw", "LOCATION"),
        ])
        resolved = resolver.resolve(triples)
        assert len(resolved) == 2

    def test_canonical_map_built(self):
        from src.resolution import EntityResolver
        resolver = EntityResolver(similarity_threshold=0.85, use_semantic=False)
        triples = self._make_triples([
            ("Marie Curie", "PERSON", "won", "Nobel Prize", "CONCEPT"),
        ])
        resolver.resolve(triples)
        assert "Marie Curie" in resolver.canonical_map

    def test_entity_summary_non_empty(self):
        from src.resolution import EntityResolver
        resolver = EntityResolver(similarity_threshold=0.85, use_semantic=False)
        triples = self._make_triples([
            ("Einstein", "PERSON", "developed", "Relativity", "CONCEPT"),
        ])
        resolver.resolve(triples)
        summary = resolver.get_entity_summary()
        assert len(summary) > 0
        assert all("name" in e and "type" in e for e in summary)


# ── Stage 4: Graph Builder ────────────────────────────────────────────────────

class TestGraphBuilder:

    def _make_triples(self, data):
        from src.extraction import Triple
        return [Triple(subject=s, subject_type=st, relation=r, object=o, object_type=ot)
                for s, st, r, o, ot in data]

    def test_graph_builds_with_correct_node_count(self):
        from src.graph_builder import GraphBuilder
        with tempfile.TemporaryDirectory() as tmpdir:
            builder = GraphBuilder(neo4j_enabled=False, output_dir=Path(tmpdir))
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
                ("Bob", "PERSON", "works_at", "Acme", "ORGANIZATION"),
            ])
            stats = builder.build(triples)
            assert stats["nodes"] == 3  # Alice, Bob, Acme
            assert stats["edges"] == 2

    def test_exports_json_and_csv(self):
        from src.graph_builder import GraphBuilder
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            builder = GraphBuilder(neo4j_enabled=False, output_dir=tmpdir)
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
            ])
            builder.build(triples)
            assert (tmpdir / "triples.json").exists()
            assert (tmpdir / "triples.csv").exists()
            assert (tmpdir / "import_graph.cypher").exists()


# ── Stage 5: Evaluation ───────────────────────────────────────────────────────

class TestEvaluation:

    def _make_triples(self, data):
        from src.extraction import Triple
        return [Triple(subject=s, subject_type=st, relation=r, object=o, object_type=ot)
                for s, st, r, o, ot in data]

    def test_evaluation_runs_without_gold(self):
        from src.evaluation import Evaluator
        from src.resolution import EntityResolver
        with tempfile.TemporaryDirectory() as tmpdir:
            evaluator = Evaluator(output_dir=Path(tmpdir))
            resolver = EntityResolver(use_semantic=False)
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
            ])
            resolver.resolve(triples)
            results = evaluator.evaluate(
                raw_triples=triples,
                resolved_triples=triples,
                resolver=resolver,
                graph_stats={"nodes": 2, "edges": 1, "density": 1.0},
            )
            assert "graph" in results
            assert "extraction" in results
            assert "entity_coverage" in results

    def test_gold_standard_precision_recall(self):
        from src.evaluation import Evaluator
        from src.resolution import EntityResolver
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            gold_path = tmpdir / "gold.txt"
            gold_path.write_text("Alice | knows | Bob\nAlice | works_at | Acme\n")

            evaluator = Evaluator(output_dir=tmpdir, gold_standard_path=gold_path)
            resolver = EntityResolver(use_semantic=False)
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
                ("Alice", "PERSON", "lives_in", "NYC", "LOCATION"),  # false positive
            ])
            resolver.resolve(triples)
            results = evaluator.evaluate(
                raw_triples=triples, resolved_triples=triples,
                resolver=resolver,
                graph_stats={"nodes": 3, "edges": 2, "density": 0.33},
            )
            gs = results["gold_standard"]
            assert gs["exact_match"]["true_positives"] == 1
            assert gs["exact_match"]["precision"] == pytest.approx(0.5, abs=0.01)
            assert gs["exact_match"]["recall"] == pytest.approx(0.5, abs=0.01)
            # top-level convenience fields should mirror the headline (fuzzy, if enabled)
            assert gs["precision"] == pytest.approx(0.5, abs=0.01)

    def test_gold_standard_fuzzy_match_credits_paraphrase(self):
        """A predicted triple phrased slightly differently from the gold
        triple should still count under fuzzy matching, but not exact."""
        from src.evaluation import Evaluator
        from src.resolution import EntityResolver
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            gold_path = tmpdir / "gold.txt"
            gold_path.write_text("Marie Curie | won | Nobel Prize in Physics\n")

            evaluator = Evaluator(
                output_dir=tmpdir, gold_standard_path=gold_path,
                fuzzy_match=True, fuzzy_threshold=80.0,
            )
            resolver = EntityResolver(use_semantic=False)
            triples = self._make_triples([
                ("Marie Curie", "PERSON", "won", "the Nobel Prize for Physics", "CONCEPT"),
            ])
            resolver.resolve(triples)
            results = evaluator.evaluate(
                raw_triples=triples, resolved_triples=triples,
                resolver=resolver,
                graph_stats={"nodes": 2, "edges": 1, "density": 1.0},
            )
            gs = results["gold_standard"]
            assert gs["exact_match"]["true_positives"] == 0
            assert gs["fuzzy_match"]["true_positives"] == 1

    def test_hallucination_section_absent_when_not_run(self):
        """Without Stage 2.5 having run, the section should say so rather
        than silently reporting a 0% hallucination rate."""
        from src.evaluation import Evaluator
        from src.resolution import EntityResolver
        with tempfile.TemporaryDirectory() as tmpdir:
            evaluator = Evaluator(output_dir=Path(tmpdir))
            resolver = EntityResolver(use_semantic=False)
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
            ])
            resolver.resolve(triples)
            results = evaluator.evaluate(
                raw_triples=triples, resolved_triples=triples,
                resolver=resolver,
                graph_stats={"nodes": 2, "edges": 1, "density": 1.0},
            )
            assert "note" in results["hallucination_check"]

    def test_hallucination_section_reports_rate(self):
        from src.evaluation import Evaluator
        from src.resolution import EntityResolver
        with tempfile.TemporaryDirectory() as tmpdir:
            evaluator = Evaluator(output_dir=Path(tmpdir))
            resolver = EntityResolver(use_semantic=False)
            triples = self._make_triples([
                ("Alice", "PERSON", "knows", "Bob", "PERSON"),
                ("Alice", "PERSON", "invented", "Time Travel", "CONCEPT"),
            ])
            triples[0].verified, triples[0].grounding_score = True, 95.0
            triples[1].verified, triples[1].grounding_score = False, 10.0
            resolver.resolve(triples)
            results = evaluator.evaluate(
                raw_triples=triples, resolved_triples=triples,
                resolver=resolver,
                graph_stats={"nodes": 3, "edges": 2, "density": 0.5},
            )
            hc = results["hallucination_check"]
            assert hc["triples_checked"] == 2
            assert hc["verified_triples"] == 1
            assert hc["unverified_triples"] == 1
            assert hc["estimated_hallucination_rate"] == pytest.approx(0.5)


# ── Stage 2.5: Hallucination Filtering ────────────────────────────────────────

class TestHallucinationFilter:

    def _make_chunk(self, text, chunk_id="c1", source_file="doc.txt"):
        from src.ingestion import DocumentChunk
        return DocumentChunk(chunk_id=chunk_id, source_file=source_file, chunk_index=0, text=text)

    def test_grounded_triple_passes(self):
        from src.verification import HallucinationFilter
        from src.extraction import Triple
        chunk = self._make_chunk("Marie Curie won the Nobel Prize in Physics in 1903.")
        t = Triple(
            subject="Marie Curie", subject_type="PERSON", relation="won",
            object="Nobel Prize in Physics", object_type="CONCEPT",
            source_chunk_id="c1", source_file="doc.txt",
        )
        filt = HallucinationFilter(chunks=[chunk], mode="flag")
        result = filt.filter([t])
        assert len(result) == 1
        assert result[0].verified is True
        assert result[0].grounding_score >= 60.0

    def test_ungrounded_triple_is_flagged_not_dropped(self):
        from src.verification import HallucinationFilter
        from src.extraction import Triple
        chunk = self._make_chunk("Marie Curie won the Nobel Prize in Physics in 1903.")
        t = Triple(
            subject="Marie Curie", subject_type="PERSON", relation="won",
            object="Turing Award", object_type="CONCEPT",  # not in the text
            source_chunk_id="c1", source_file="doc.txt",
        )
        filt = HallucinationFilter(chunks=[chunk], mode="flag")
        result = filt.filter([t])
        assert len(result) == 1  # flag mode keeps it
        assert result[0].verified is False

    def test_ungrounded_triple_dropped_in_drop_mode(self):
        from src.verification import HallucinationFilter
        from src.extraction import Triple
        chunk = self._make_chunk("Marie Curie won the Nobel Prize in Physics in 1903.")
        t = Triple(
            subject="Marie Curie", subject_type="PERSON", relation="won",
            object="Turing Award", object_type="CONCEPT",
            source_chunk_id="c1", source_file="doc.txt",
        )
        filt = HallucinationFilter(chunks=[chunk], mode="drop")
        result = filt.filter([t])
        assert len(result) == 0
        assert filt.last_stats["dropped"] == 1

    def test_ungrounded_triple_downweighted(self):
        from src.verification import HallucinationFilter
        from src.extraction import Triple
        chunk = self._make_chunk("Marie Curie won the Nobel Prize in Physics in 1903.")
        t = Triple(
            subject="Marie Curie", subject_type="PERSON", relation="won",
            object="Turing Award", object_type="CONCEPT", confidence=0.9,
            source_chunk_id="c1", source_file="doc.txt",
        )
        filt = HallucinationFilter(chunks=[chunk], mode="downweight")
        result = filt.filter([t])
        assert result[0].confidence == pytest.approx(0.45)

    def test_missing_source_chunk_scores_zero(self):
        from src.verification import HallucinationFilter
        from src.extraction import Triple
        t = Triple(
            subject="Marie Curie", subject_type="PERSON", relation="won",
            object="Nobel Prize", object_type="CONCEPT",
            source_chunk_id="does_not_exist", source_file="doc.txt",
        )
        filt = HallucinationFilter(chunks=[], mode="flag")
        result = filt.filter([t])
        assert result[0].grounding_score == 0.0
        assert result[0].verified is False

    def test_invalid_mode_raises(self):
        from src.verification import HallucinationFilter
        with pytest.raises(ValueError):
            HallucinationFilter(chunks=[], mode="not_a_real_mode")


# ── Multi-LLM Consensus Framework ───────────────────────────────────────────

class _FakeProvider:
    """Minimal stand-in for src.providers.BaseLLM used in unit tests — avoids
    any real network/Ollama/Gemini calls."""

    def __init__(self, name, extraction_response, verification_response):
        self.name = name
        self._extraction_response = extraction_response
        self._verification_response = verification_response

    async def extract_triples_raw(self, chunk_text):
        return self._extraction_response

    async def verify_triple_raw(self, source_text, triple_str):
        return self._verification_response


class TestMultiLLMExtractor:

    def test_independent_extraction_keeps_graphs_separate(self):
        import asyncio
        from src.extraction import MultiLLMExtractor
        from src.ingestion import DocumentChunk

        chunk = DocumentChunk(chunk_id="c1", source_file="doc.txt", chunk_index=0, text="Marie Curie won the Nobel Prize.")
        providers = {
            "gemini": _FakeProvider(
                "gemini",
                '{"triples": [{"subject": "Marie Curie", "subject_type": "PERSON", "relation": "won", "object": "Nobel Prize", "object_type": "CONCEPT", "confidence": 0.9}]}',
                '{"supported": true, "evidence": "x"}',
            ),
            "llama": _FakeProvider(
                "llama",
                '{"triples": []}',
                '{"supported": false, "evidence": ""}',
            ),
        }
        extractor = MultiLLMExtractor(providers)
        graphs = asyncio.run(extractor.extract_all([chunk]))

        assert set(graphs.keys()) == {"gemini", "llama"}
        assert len(graphs["gemini"]) == 1
        assert graphs["gemini"][0].generator_model == "gemini"
        assert len(graphs["llama"]) == 0


class TestVerificationManagerAndConsensus:

    def _make_triple(self, generator):
        from src.extraction import Triple
        return Triple(
            subject="Apple", subject_type="ORGANIZATION", relation="acquired",
            object="Beats", object_type="ORGANIZATION",
            source_chunk_id="c1", source_file="doc.txt",
            generator_model=generator,
        )

    def test_agreement_score_unanimous(self):
        import asyncio
        from src.verification import VerificationManager
        from src.ingestion import DocumentChunk

        chunk = DocumentChunk(chunk_id="c1", source_file="doc.txt", chunk_index=0, text="Apple acquired Beats in 2014.")
        t = self._make_triple("gemini")
        providers = {
            "gemini": _FakeProvider("gemini", "", '{"supported": true, "evidence": "Apple acquired Beats in 2014."}'),
            "llama": _FakeProvider("llama", "", '{"supported": true, "evidence": "Apple acquired Beats in 2014."}'),
            "qwen": _FakeProvider("qwen", "", '{"supported": true, "evidence": "Apple acquired Beats in 2014."}'),
        }
        vm = VerificationManager(providers=providers, chunks=[chunk])
        verified = asyncio.run(vm.cross_verify({"gemini": [t]}))

        assert len(verified) == 1
        assert verified[0].agreement_score == 1.0
        assert len(verified[0].verification_results) == 2  # verified by llama + qwen, not itself

    def test_not_supported_never_carries_evidence(self):
        import asyncio
        from src.verification import VerificationManager
        from src.ingestion import DocumentChunk

        chunk = DocumentChunk(chunk_id="c1", source_file="doc.txt", chunk_index=0, text="Apple makes phones.")
        t = self._make_triple("gemini")
        providers = {
            "gemini": _FakeProvider("gemini", "", '{"supported": false, "evidence": "should be discarded"}'),
            "llama": _FakeProvider("llama", "", '{"supported": false, "evidence": ""}'),
        }
        vm = VerificationManager(providers=providers, chunks=[chunk])
        verified = asyncio.run(vm.cross_verify({"llama": [t]}))

        assert verified[0].agreement_score == 0.0
        assert all(r["evidence"] == "" for r in verified[0].verification_results)

    def test_consensus_manager_applies_threshold(self):
        from src.consensus import ConsensusManager
        t_high = self._make_triple("gemini")
        t_high.agreement_score = 1.0
        t_low = self._make_triple("llama")
        t_low.agreement_score = 0.0

        cm = ConsensusManager(min_agreement_score=0.5)
        accepted, rejected = cm.select_consensus([t_high, t_low])

        assert accepted == [t_high]
        assert rejected == [t_low]
        assert t_high.consensus_status == "accepted"
        assert t_low.consensus_status == "rejected"

    def test_consensus_manager_deduplicates_cross_model_facts(self):
        from src.consensus import ConsensusManager
        t1 = self._make_triple("gemini")
        t1.agreement_score = 1.0
        t2 = self._make_triple("llama")
        t2.agreement_score = 0.5

        cm = ConsensusManager(min_agreement_score=0.5)
        accepted, rejected = cm.select_consensus([t1, t2])

        assert len(accepted) == 1  # same (subject, relation, object) -> merged
        assert accepted[0].agreement_score == 1.0  # kept the higher-agreement instance
        assert cm.last_stats["duplicate_facts_merged"] == 1


class TestTripleAligner:

    def test_aligns_entities_via_shared_resolver(self):
        from src.extraction import Triple
        from src.resolution import EntityResolver
        from src.consensus import TripleAligner

        triples = [
            Triple(subject="Marie Curie", subject_type="PERSON", relation="won", object="Nobel Prize", object_type="CONCEPT"),
        ]
        resolver = EntityResolver(use_semantic=False)
        resolver.resolve(triples)
        # Simulate a paraphrase from a different model pointing at the same canonical entity
        other = Triple(subject="Marie Curie", subject_type="PERSON", relation="acquired", object="Nobel Prize", object_type="CONCEPT")

        aligner = TripleAligner(resolver)
        aligned = aligner.align([other])
        assert aligned[0].subject == resolver.canonical_map.get("Marie Curie", "Marie Curie")

    def test_relation_clustering_merges_paraphrases(self):
        from src.extraction import Triple
        from src.resolution import EntityResolver
        from src.consensus import TripleAligner

        resolver = EntityResolver(use_semantic=False)
        resolver.resolve([])
        triples = [
            Triple(subject="Apple", subject_type="ORGANIZATION", relation="acquired", object="Beats", object_type="ORGANIZATION"),
            Triple(subject="Apple", subject_type="ORGANIZATION", relation="acquird", object="Beats", object_type="ORGANIZATION"),
        ]
        aligner = TripleAligner(resolver, relation_similarity_threshold=0.80)
        aligned = aligner.align(triples)
        assert aligned[0].relation == aligned[1].relation


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
