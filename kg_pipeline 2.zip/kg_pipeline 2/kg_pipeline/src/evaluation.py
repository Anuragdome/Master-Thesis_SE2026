"""
src/evaluation.py
=================
Stage 5: Knowledge Graph Evaluation

Computes metrics that go into your thesis:
  - Graph structure statistics (nodes, edges, density)
  - Entity type distribution
  - Relation diversity
  - Extraction coverage per document
  - Precision & recall against a gold standard (if provided)
  - Per-chunk extraction success rate
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from collections import defaultdict, Counter

from src.extraction import Triple
from src.resolution import EntityResolver

logger = logging.getLogger(__name__)


class Evaluator:
    """
    Computes evaluation metrics for the knowledge graph pipeline.
    Generates a human-readable report saved to data/output/.
    """

    def __init__(
        self,
        output_dir: Path = Path("data/output"),
        gold_standard_path: Optional[Path] = None,
    ):
        self.output_dir = Path(output_dir)
        self.gold_standard_path = gold_standard_path

    def evaluate(
        self,
        raw_triples: List[Triple],
        resolved_triples: List[Triple],
        resolver: EntityResolver,
        graph_stats: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Run all evaluations and return a results dict.
        Also writes a text report to data/output/evaluation_report.txt.
        """
        results: Dict[str, Any] = {}

        results["graph"] = graph_stats
        results["extraction"] = self._extraction_stats(raw_triples, resolved_triples)
        results["entity_coverage"] = self._entity_coverage(resolved_triples)
        results["relation_analysis"] = self._relation_analysis(resolved_triples)
        results["resolution"] = self._resolution_stats(resolver)

        if self.gold_standard_path and Path(self.gold_standard_path).exists():
            results["gold_standard"] = self._gold_standard_eval(resolved_triples)
        else:
            results["gold_standard"] = {
                "note": "No gold standard provided. Add a gold_standard.txt file to enable precision/recall."
            }

        self._write_report(results)
        self._write_json(results)
        return results

    # ── Evaluation sections ───────────────────────────────────────────────

    def _extraction_stats(
        self, raw: List[Triple], resolved: List[Triple]
    ) -> Dict[str, Any]:
        sources = defaultdict(int)
        for t in raw:
            sources[t.source_file] += 1

        return {
            "total_raw_triples": len(raw),
            "total_resolved_triples": len(resolved),
            "unique_relations": len({t.relation for t in resolved}),
            "triples_per_document": dict(sources),
            "avg_triples_per_chunk": round(
                len(raw) / max(len({t.source_chunk_id for t in raw}), 1), 2
            ),
        }

    def _entity_coverage(self, triples: List[Triple]) -> Dict[str, Any]:
        subjects = {t.subject for t in triples}
        objects = {t.object for t in triples}
        all_entities = subjects | objects

        type_counts: Dict[str, int] = defaultdict(int)
        for t in triples:
            type_counts[t.subject_type] += 1
            type_counts[t.object_type] += 1

        return {
            "unique_entities": len(all_entities),
            "entities_as_subject_only": len(subjects - objects),
            "entities_as_object_only": len(objects - subjects),
            "entities_in_both_roles": len(subjects & objects),
            "entity_type_distribution": dict(type_counts),
        }

    def _relation_analysis(self, triples: List[Triple]) -> Dict[str, Any]:
        relation_counts = Counter(t.relation for t in triples)
        avg_confidence = (
            sum(t.confidence for t in triples) / len(triples)
            if triples else 0
        )
        low_confidence = [
            str(t) for t in triples if t.confidence < 0.7
        ]

        return {
            "unique_relation_types": len(relation_counts),
            "most_common_relations": relation_counts.most_common(10),
            "average_confidence": round(avg_confidence, 3),
            "low_confidence_triples_count": len(low_confidence),
            "low_confidence_examples": low_confidence[:5],
        }

    def _resolution_stats(self, resolver: EntityResolver) -> Dict[str, Any]:
        total_names = len(resolver.canonical_map)
        canonical_count = len(set(resolver.canonical_map.values()))
        merged = total_names - canonical_count

        alias_sizes = [
            len(aliases)
            for aliases in resolver.aliases.values()
            if len(aliases) > 1
        ]

        return {
            "total_entity_strings_before_resolution": total_names,
            "canonical_entities_after_resolution": canonical_count,
            "aliases_merged": merged,
            "largest_alias_group_size": max(alias_sizes, default=0),
            "avg_aliases_per_merged_entity": (
                round(sum(alias_sizes) / len(alias_sizes), 2) if alias_sizes else 0
            ),
        }

    def _gold_standard_eval(
        self, resolved_triples: List[Triple]
    ) -> Dict[str, Any]:
        """
        Compute precision and recall against a gold standard file.
        Gold standard format (one line per triple):
            Marie Curie | won | Nobel Prize in Physics
        """
        gold: List[Tuple[str, str, str]] = []
        with open(self.gold_standard_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = [p.strip() for p in line.split("|")]
                if len(parts) == 3:
                    gold.append((parts[0].lower(), parts[1].lower(), parts[2].lower()))

        predicted = {
            (t.subject.lower(), t.relation.lower(), t.object.lower())
            for t in resolved_triples
        }
        gold_set = set(gold)

        tp = len(predicted & gold_set)
        precision = tp / len(predicted) if predicted else 0
        recall = tp / len(gold_set) if gold_set else 0
        f1 = (
            2 * precision * recall / (precision + recall)
            if (precision + recall) > 0
            else 0
        )

        return {
            "gold_triples": len(gold_set),
            "predicted_triples": len(predicted),
            "true_positives": tp,
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1_score": round(f1, 4),
        }

    # ── Report writing ────────────────────────────────────────────────────

    def _write_report(self, results: Dict[str, Any]) -> None:
        lines = []
        lines.append("=" * 60)
        lines.append("  KNOWLEDGE GRAPH PIPELINE — EVALUATION REPORT")
        lines.append("=" * 60)

        lines.append("\n[ GRAPH STRUCTURE ]")
        g = results["graph"]
        lines.append(f"  Nodes (entities):  {g.get('nodes', 0)}")
        lines.append(f"  Edges (relations): {g.get('edges', 0)}")
        lines.append(f"  Graph density:     {g.get('density', 0):.4f}")

        lines.append("\n[ EXTRACTION ]")
        e = results["extraction"]
        lines.append(f"  Raw triples extracted:    {e['total_raw_triples']}")
        lines.append(f"  Resolved triples:         {e['total_resolved_triples']}")
        lines.append(f"  Unique relation types:    {e['unique_relations']}")
        lines.append(f"  Avg triples per chunk:    {e['avg_triples_per_chunk']}")
        lines.append("\n  Triples per document:")
        for doc, count in e["triples_per_document"].items():
            lines.append(f"    {doc}: {count}")

        lines.append("\n[ ENTITY COVERAGE ]")
        ec = results["entity_coverage"]
        lines.append(f"  Unique entities:          {ec['unique_entities']}")
        lines.append(f"  Appear as subject only:   {ec['entities_as_subject_only']}")
        lines.append(f"  Appear as object only:    {ec['entities_as_object_only']}")
        lines.append(f"  Appear in both roles:     {ec['entities_in_both_roles']}")
        lines.append("\n  Entity type distribution:")
        for etype, count in sorted(ec["entity_type_distribution"].items(), key=lambda x: -x[1]):
            lines.append(f"    {etype}: {count}")

        lines.append("\n[ ENTITY RESOLUTION ]")
        r = results["resolution"]
        lines.append(f"  Strings before resolution: {r['total_entity_strings_before_resolution']}")
        lines.append(f"  Canonical entities after:  {r['canonical_entities_after_resolution']}")
        lines.append(f"  Aliases merged:            {r['aliases_merged']}")
        lines.append(f"  Largest alias group:       {r['largest_alias_group_size']}")

        lines.append("\n[ RELATION ANALYSIS ]")
        ra = results["relation_analysis"]
        lines.append(f"  Unique relation types:     {ra['unique_relation_types']}")
        lines.append(f"  Average confidence:        {ra['average_confidence']}")
        lines.append(f"  Low-confidence triples:    {ra['low_confidence_triples_count']}")
        lines.append("\n  Most common relations:")
        for rel, count in ra["most_common_relations"]:
            lines.append(f"    {rel}: {count}")

        lines.append("\n[ GOLD STANDARD EVALUATION ]")
        gs = results["gold_standard"]
        if "note" in gs:
            lines.append(f"  {gs['note']}")
        else:
            lines.append(f"  Gold triples:    {gs['gold_triples']}")
            lines.append(f"  Predicted:       {gs['predicted_triples']}")
            lines.append(f"  True positives:  {gs['true_positives']}")
            lines.append(f"  Precision:       {gs['precision']:.4f}")
            lines.append(f"  Recall:          {gs['recall']:.4f}")
            lines.append(f"  F1 Score:        {gs['f1_score']:.4f}")

        lines.append("\n" + "=" * 60)

        report = "\n".join(lines)
        print(report)

        out = self.output_dir / "evaluation_report.txt"
        out.write_text(report)
        logger.info(f"Evaluation report saved → {out}")

    def _write_json(self, results: Dict[str, Any]) -> None:
        out = self.output_dir / "evaluation_results.json"

        def make_serializable(obj):
            if isinstance(obj, dict):
                return {k: make_serializable(v) for k, v in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [make_serializable(i) for i in obj]
            elif isinstance(obj, set):
                return sorted(list(obj))
            elif isinstance(obj, Path):
                return str(obj)
            return obj

        out.write_text(json.dumps(make_serializable(results), indent=2))
