"""
src/ingestion.py
================
Stage 1: Document Ingestion

Loads documents from data/raw/, strips noise, and splits them
into chunks that the LLM can process.

Supported formats: .txt, .pdf, .html
"""

import logging
from pathlib import Path
from typing import List, Dict, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class DocumentChunk:
    """A single chunk of text from a source document."""
    chunk_id: str
    source_file: str
    chunk_index: int
    text: str
    metadata: Dict[str, Any] = field(default_factory=dict)


class DocumentIngester:
    """
    Loads raw documents, cleans them, and splits them into
    overlapping chunks ready for LLM extraction.
    """

    def __init__(self, chunk_size: int = 800, chunk_overlap: int = 100):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    # ── Public API ────────────────────────────────────────────────────────

    def ingest_directory(self, directory: Path) -> List[DocumentChunk]:
        """
        Load all supported documents from a directory.
        Returns a flat list of DocumentChunk objects.
        """
        directory = Path(directory)
        all_chunks: List[DocumentChunk] = []

        files = list(directory.glob("**/*"))
        supported = [f for f in files if f.suffix.lower() in {".txt", ".pdf", ".html", ".htm"}]

        if not supported:
            logger.warning(f"No supported documents found in {directory}")
            logger.info("Generating sample documents for demonstration...")
            self._write_sample_documents(directory)
            supported = list(directory.glob("*.txt"))

        logger.info(f"Found {len(supported)} document(s) to ingest")

        for file_path in supported:
            try:
                chunks = self._process_file(file_path)
                all_chunks.extend(chunks)
                logger.info(f"  {file_path.name}: {len(chunks)} chunk(s)")
            except Exception as e:
                logger.error(f"  Failed to process {file_path.name}: {e}")

        logger.info(f"Total chunks produced: {len(all_chunks)}")
        return all_chunks

    def ingest_text(self, text: str, source_name: str = "manual_input") -> List[DocumentChunk]:
        """Ingest a raw text string directly."""
        cleaned = self._clean_text(text)
        return self._chunk_text(cleaned, source_name)

    # ── Private helpers ───────────────────────────────────────────────────

    def _process_file(self, path: Path) -> List[DocumentChunk]:
        suffix = path.suffix.lower()
        if suffix == ".txt":
            text = self._load_txt(path)
        elif suffix == ".pdf":
            text = self._load_pdf(path)
        elif suffix in {".html", ".htm"}:
            text = self._load_html(path)
        else:
            raise ValueError(f"Unsupported file type: {suffix}")

        cleaned = self._clean_text(text)
        return self._chunk_text(cleaned, path.name)

    def _load_txt(self, path: Path) -> str:
        return path.read_text(encoding="utf-8", errors="ignore")

    def _load_pdf(self, path: Path) -> str:
        try:
            import fitz  # PyMuPDF
            doc = fitz.open(str(path))
            pages = [page.get_text() for page in doc]
            doc.close()
            return "\n\n".join(pages)
        except ImportError:
            logger.warning("PyMuPDF not installed. Falling back to raw read.")
            return path.read_bytes().decode("utf-8", errors="ignore")

    def _load_html(self, path: Path) -> str:
        try:
            from bs4 import BeautifulSoup
            html = path.read_text(encoding="utf-8", errors="ignore")
            soup = BeautifulSoup(html, "lxml")
            # Remove script/style tags
            for tag in soup(["script", "style", "nav", "footer"]):
                tag.decompose()
            return soup.get_text(separator="\n")
        except ImportError:
            logger.warning("BeautifulSoup not installed. Stripping HTML tags naively.")
            import re
            text = path.read_text(encoding="utf-8", errors="ignore")
            return re.sub(r"<[^>]+>", " ", text)

    def _clean_text(self, text: str) -> str:
        """Remove excessive whitespace, normalize line endings."""
        import re
        # Normalize line endings
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        # Collapse 3+ newlines into 2
        text = re.sub(r"\n{3,}", "\n\n", text)
        # Collapse multiple spaces
        text = re.sub(r" {2,}", " ", text)
        # Strip leading/trailing whitespace per line
        lines = [line.strip() for line in text.split("\n")]
        text = "\n".join(lines)
        return text.strip()

    def _chunk_text(self, text: str, source_name: str) -> List[DocumentChunk]:
        """
        Split text into overlapping chunks of self.chunk_size characters.
        Tries to split on sentence boundaries to avoid cutting mid-sentence.
        """
        chunks = []
        start = 0
        chunk_index = 0

        while start < len(text):
            end = start + self.chunk_size

            # Try to end at a sentence boundary (. ! ?) if we're not at the end
            if end < len(text):
                # Look back up to 200 chars for a sentence end
                search_start = max(start + self.chunk_size // 2, end - 200)
                boundary = -1
                for i in range(end, search_start, -1):
                    if text[i] in ".!?\n":
                        boundary = i + 1
                        break
                if boundary > start:
                    end = boundary

            chunk_text = text[start:end].strip()
            if chunk_text:
                chunks.append(DocumentChunk(
                    chunk_id=f"{source_name}_chunk_{chunk_index:04d}",
                    source_file=source_name,
                    chunk_index=chunk_index,
                    text=chunk_text,
                    metadata={"start_char": start, "end_char": end}
                ))
                chunk_index += 1

            # Move forward with overlap
            start = end - self.chunk_overlap
            if start >= len(text):
                break

        return chunks

    def _write_sample_documents(self, directory: Path) -> None:
        """Write sample documents so the pipeline can run out of the box."""
        sample1 = """
Marie Curie was a Polish-French physicist and chemist who conducted pioneering research on radioactivity.
She was the first woman to win a Nobel Prize, the only person to win Nobel Prizes in two different sciences
(Physics in 1903 and Chemistry in 1911), and the only person to win the Nobel Prize twice in sciences.

She was born Maria Sklodowska in Warsaw, Poland in 1867. She studied at the University of Paris (Sorbonne),
where she later became the first female professor. Together with her husband Pierre Curie, she discovered
two elements: polonium (named after her homeland) and radium. The Curie Institute in Paris, which she
co-founded, remains a major cancer research centre.

Curie developed the theory of radioactivity (a term she coined) and techniques for isolating radioactive
isotopes. Her work led to the development of X-ray machines used in World War I. She died in 1934 from
aplastic anaemia caused by her extensive exposure to radiation.
        """.strip()

        sample2 = """
Albert Einstein was a German-born theoretical physicist who is widely held to be one of the greatest
scientists of all time. He developed the theory of relativity, one of the two pillars of modern physics
alongside quantum mechanics. His work is also known for its influence on the philosophy of science.

Einstein received the Nobel Prize in Physics in 1921 for his discovery of the law of the photoelectric
effect. He worked at the Swiss Patent Office in Bern and later at the Institute for Advanced Study in
Princeton, New Jersey. His famous equation E=mc² describes the equivalence of energy and mass.

Einstein collaborated with many scientists including Niels Bohr, with whom he famously debated the
foundations of quantum mechanics. He was a professor at the University of Berlin and the Swiss Federal
Polytechnic School (ETH Zurich). He fled Nazi Germany in 1933 and became a United States citizen in 1940.
        """.strip()

        sample3 = """
OpenAI is an American artificial intelligence research laboratory consisting of the non-profit OpenAI Inc.
and its for-profit subsidiary OpenAI LP. The company was founded in December 2015 by Sam Altman, Elon Musk,
Greg Brockman, Ilya Sutskever, Wojciech Zaremba, and John Schulman.

OpenAI is headquartered in San Francisco, California. The company developed the GPT series of large language
models, including GPT-3 and GPT-4, as well as the DALL-E image generation system and the Codex code
generation model. Their conversational AI system ChatGPT was released in November 2022 and became the
fastest-growing consumer application in history.

Microsoft has invested heavily in OpenAI, with a reported investment of $13 billion. OpenAI's research
has been published in top venues including NeurIPS and ICML. The company also created the Gym toolkit
for reinforcement learning research, which is widely used by the AI research community.
        """.strip()

        (directory / "marie_curie.txt").write_text(sample1)
        (directory / "albert_einstein.txt").write_text(sample2)
        (directory / "openai.txt").write_text(sample3)
        logger.info("Wrote 3 sample documents to data/raw/")
