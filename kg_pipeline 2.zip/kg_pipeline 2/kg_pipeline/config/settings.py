"""
config/settings.py
==================
Central configuration for the Knowledge Graph Pipeline.
Edit this file to change API keys, models, and pipeline behaviour.
"""

import os
from pathlib import Path

# ─────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────
BASE_DIR       = Path(__file__).parent.parent
DATA_RAW       = BASE_DIR / "data" / "raw"
DATA_PROCESSED = BASE_DIR / "data" / "processed"
DATA_OUTPUT    = BASE_DIR / "data" / "output"

# Create dirs if they don't exist
for d in [DATA_RAW, DATA_PROCESSED, DATA_OUTPUT]:
    d.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────────────────────
# LLM SETTINGS
# ─────────────────────────────────────────────

# Provider: "anthropic" or "openai"
#LLM_PROVIDER = "anthropic"
LLM_PROVIDER = "gemini"

# Your API key — or set the env variable ANTHROPIC_API_KEY / OPENAI_API_KEY
#ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "YOUR_ANTHROPIC_API_KEY_HERE")
#OPENAI_API_KEY    = os.getenv("OPENAI_API_KEY",    "YOUR_OPENAI_API_KEY_HERE")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyAQI_xpIavx-rfYHGPCABHrN5Pmex3e0OU")
# Model to use
# Anthropic options: "claude-opus-4-6", "claude-sonnet-4-6", "claude-haiku-4-5-20251001"
# OpenAI options:    "gpt-4o", "gpt-4o-mini"
#MODEL_NAME = "claude-opus-4-6"
MODEL_NAME = "gemini-2.5-flash"
# Max tokens the LLM will generate per extraction call
MAX_TOKENS = 2000

# Temperature — 0 = deterministic, good for structured extraction
TEMPERATURE = 0.0

# ─────────────────────────────────────────────
# DOCUMENT CHUNKING
# ─────────────────────────────────────────────

# Characters per chunk sent to the LLM
CHUNK_SIZE = 800

# Overlap between consecutive chunks (so entities at boundaries aren't missed)
CHUNK_OVERLAP = 100

# ─────────────────────────────────────────────
# ENTITY EXTRACTION
# ─────────────────────────────────────────────

# Entity types the LLM should look for
ENTITY_TYPES = [
    "PERSON",
    "ORGANIZATION",
    "LOCATION",
    "CONCEPT",
    "EVENT",
    "PRODUCT",
    "DATE",
    "TECHNOLOGY",
]

# Relation types to guide extraction (LLM can also discover new ones)
RELATION_TYPES = [
    "works_for",
    "located_in",
    "founded_by",
    "part_of",
    "created",
    "participated_in",
    "related_to",
    "caused_by",
    "used_in",
    "developed_by",
]

# ─────────────────────────────────────────────
# ENTITY RESOLUTION
# ─────────────────────────────────────────────

# Fuzzy string similarity threshold (0.0–1.0).
# Entities above this threshold are considered the same.
# Lower = more aggressive merging. Start at 0.85.
SIMILARITY_THRESHOLD = 0.85

# Use sentence-transformer embeddings for semantic similarity?
# More accurate but slower. Set False for fuzzy-only (fast).
USE_SEMANTIC_SIMILARITY = True

# Sentence transformer model for embeddings
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# ─────────────────────────────────────────────
# NEO4J SETTINGS
# ─────────────────────────────────────────────

# Set to False to skip Neo4j entirely (still exports to JSON/CSV)
NEO4J_ENABLED = True

NEO4J_URI      = os.getenv("NEO4J_URI",      "bolt://localhost:7687")
NEO4J_USER     = os.getenv("NEO4J_USER",     "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "password")

# ─────────────────────────────────────────────
# EVALUATION
# ─────────────────────────────────────────────

# Path to a gold standard triples file for precision/recall evaluation.
# Format: one triple per line — "subject | relation | object"
# Leave as None to skip gold-standard evaluation.
GOLD_STANDARD_PATH = None  # e.g. BASE_DIR / "data" / "gold_standard.txt"

# ─────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────

LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
