"""
src/verification.py
====================
Stage 2.5: Hallucination Filtering & Verification

LLMs extracting triples don't only make parsing mistakes — they sometimes
state facts that are plausible-sounding but were never actually written in
the source text (classic hallucination). This stage catches that class of
error before the triples reach entity resolution and the graph.

Two complementary checks, both optional and independently configurable:

  1. Lexical grounding (always cheap, always on by default)
     For every triple, checks whether its subject and object strings
     actually occur (exactly or fuzzily, via rapidfuzz) inside the exact
     source chunk the triple claims to come from. A triple whose entities
     can't be found anywhere near that text is very likely invented or
     misattributed to the wrong chunk.

  2. LLM self-verification (opt-in, costs one extra API call per triple)
     A second, independent LLM call is shown ONLY the source passage and
     the candidate triple, and asked a strict yes/no question: "is this
     explicitly stated here?". This catches hallucinations that pass the
     lexical check because the entity names are real words from the text,
     but the *relation between them* was never actually stated (e.g. the
     text mentions both "Einstein" and "Princeton" but never says he was
     born there).

Every triple that passes through this stage gets a `grounding_score` and
a `verified` flag (see src/extraction.py::Triple), which the evaluation
stage (src/evaluation.py) turns into an estimated hallucination rate for
the thesis write-up.
"""

import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import List, Dict, Optional, Any

from rapidfuzz import fuzz

from src.extraction import Triple, strip_code_fences
from src.ingestion import DocumentChunk

logger = logging.getLogger(__name__)


class HallucinationFilter:
    """
    Checks each extracted triple for evidence that it is actually grounded
    in the source text, and either flags, down-weights, or drops the ones
    that aren't.

    Usage:
        filt = HallucinationFilter(chunks=chunks, mode="flag")
        clean_triples = filt.filter(raw_triples)
        print(filt.last_stats)
    """

    def __init__(
        self,
        chunks: List[DocumentChunk],
        grounding_threshold: float = 60.0,
        mode: str = "flag",
        use_llm_verification: bool = False,
        extractor=None,
        min_confidence: float = 0.0,
    ):
        """
        chunks:               the same DocumentChunk list that was sent for
                               extraction, used to look up each triple's
                               source text by chunk_id.
        grounding_threshold:  0-100 rapidfuzz partial_ratio score. Below
                               this, a triple's subject/object is considered
                               "not found" in the source chunk.
        mode:                 what to do with triples that fail verification:
                                 "flag"       -> keep, just mark verified=False
                                 "downweight" -> keep, halve their confidence
                                 "drop"       -> remove from the pipeline
        use_llm_verification: if True, triples that pass the lexical check
                               are ALSO sent back to the LLM for a stricter
                               independent yes/no check. Requires `extractor`.
        extractor:             an LLMExtractor instance (reused so the API
                               key/client is shared) — required only if
                               use_llm_verification=True.
        min_confidence:       triples with confidence below this (after any
                               down-weighting) are dropped regardless of mode.
        """
        if mode not in {"flag", "downweight", "drop"}:
            raise ValueError(f"Unknown mode: {mode!r}. Use 'flag', 'downweight', or 'drop'.")

        self.chunk_lookup: Dict[str, str] = {c.chunk_id: c.text for c in chunks}
        self.grounding_threshold = grounding_threshold
        self.mode = mode
        self.use_llm_verification = use_llm_verification
        self.extractor = extractor
        self.min_confidence = min_confidence
        self.last_stats: Dict[str, int] = {}

        if use_llm_verification and extractor is None:
            logger.warning(
                "use_llm_verification=True but no extractor was provided — "
                "falling back to lexical-only grounding."
            )
            self.use_llm_verification = False

    # ── Public API ────────────────────────────────────────────────────────

    def filter(self, triples: List[Triple]) -> List[Triple]:
        """
        Run grounding (+ optional LLM verification) over every triple and
        return the surviving list according to `mode`. Populates
        `self.last_stats` with counts for the evaluation report.
        """
        out: List[Triple] = []
        stats = {
            "total": len(triples),
            "lexically_grounded": 0,
            "lexically_ungrounded": 0,
            "llm_checked": 0,
            "llm_rejected": 0,
            "verified": 0,
            "unverified": 0,
            "dropped": 0,
            "downweighted": 0,
        }

        for t in triples:
            source_text = self.chunk_lookup.get(t.source_chunk_id, "")
            score = self._grounding_score(t, source_text)
            t.grounding_score = score
            lexically_grounded = score >= self.grounding_threshold
            t.verification_method = "lexical"

            if lexically_grounded:
                stats["lexically_grounded"] += 1
            else:
                stats["lexically_ungrounded"] += 1

            verified = lexically_grounded

            # Only bother with the (expensive) LLM check for triples that
            # already look grounded lexically — no point spending an API
            # call confirming what's already obviously ungrounded.
            if verified and self.use_llm_verification:
                stats["llm_checked"] += 1
                verified = self.extractor.verify_triple(t, source_text)
                t.verification_method = "llm"
                if not verified:
                    stats["llm_rejected"] += 1

            t.verified = verified
            if verified:
                stats["verified"] += 1
            else:
                stats["unverified"] += 1

            if not verified:
                if self.mode == "drop":
                    stats["dropped"] += 1
                    continue
                elif self.mode == "downweight":
                    t.confidence = round(t.confidence * 0.5, 3)
                    stats["downweighted"] += 1
                # mode == "flag": keep as-is, just marked verified=False

            if t.confidence < self.min_confidence:
                stats["dropped"] += 1
                continue

            out.append(t)

        self.last_stats = stats
        logger.info(
            f"  Hallucination filter: {stats['verified']}/{stats['total']} triples verified "
            f"({stats['unverified']} flagged, {stats['dropped']} dropped, mode='{self.mode}')"
        )
        if stats["llm_checked"]:
            logger.info(
                f"  LLM verification pass: {stats['llm_checked']} checked, "
                f"{stats['llm_rejected']} rejected"
            )
        return out

    # ── Private helpers ───────────────────────────────────────────────────

    def _grounding_score(self, t: Triple, source_text: str) -> float:
        """
        0-100 lexical grounding score for a triple against its claimed
        source chunk. Uses the *weaker* of the subject/object match so a
        triple can't hide one hallucinated entity behind one real one.

        rapidfuzz.partial_ratio is used (rather than a full-string ratio)
        because entity names are short substrings of a much longer chunk,
        so we want "does this substring appear somewhere in here", not
        "how similar is this string to the whole chunk".
        """
        if not source_text or not t.subject or not t.object:
            return 0.0
        subj_score = fuzz.partial_ratio(t.subject.lower(), source_text.lower())
        obj_score = fuzz.partial_ratio(t.object.lower(), source_text.lower())
        return round(min(subj_score, obj_score), 2)


class VerificationManager:
    """
    Step 3/4/5 — Cross Verification, Evidence-Based Verification, and
    Agreement Score computation.

    Every triple generated by one model is sent — together with its exact
    source chunk text — to each of the OTHER configured models, with the
    strict prompt:

        "Determine whether this triple is explicitly supported by the
         provided source text. Return JSON only.
         {supported:true/false, evidence:'exact supporting sentence'}"

    A verifier that claims "supported" without pointing at real evidence
    text, or that fails to return parseable JSON, is treated as NOT
    supporting the triple (fails closed for correctness of the Agreement
    Score, in contrast to the legacy single-model verify_triple() which
    fails open — see src/extraction.py::LLMExtractor.verify_triple).

    Agreement Score = (# verifying models that returned supported=True)
                       / (# verifying models)

    This becomes Triple.agreement_score, completely replacing the old
    single-model `confidence` field as the primary, fully-explainable
    trust metric (Step 5). Runs all verification calls concurrently via
    asyncio (Step 10).
    """

    def __init__(
        self,
        providers: Dict[str, Any],
        chunks: List[DocumentChunk],
        enable_evidence_storage: bool = True,
    ):
        """
        providers:              {name: BaseLLM} — every model in the consensus
                                 framework (see src/providers.py). Each triple
                                 is verified by every provider EXCEPT the one
                                 that generated it.
        chunks:                 the same DocumentChunk list used for
                                 extraction, used to look up each triple's
                                 exact source text by chunk_id.
        enable_evidence_storage: if False, verification still runs (needed
                                 for the Agreement Score) but evidence
                                 sentences are discarded to save space.
        """
        self.providers = providers
        self.chunk_lookup: Dict[str, str] = {c.chunk_id: c.text for c in chunks}
        self.enable_evidence_storage = enable_evidence_storage
        self.last_stats: Dict[str, Any] = {}

    async def cross_verify(self, triples_by_model: Dict[str, List[Triple]]) -> List[Triple]:
        """
        For every (generator, triples) pair, verify each triple with every
        OTHER provider. Mutates and returns a flat list containing every
        triple from every model's independent graph, each now carrying
        `verification_results`, `agreement_score` and `timestamp`.
        """
        flat: List[tuple] = []
        for generator_name, triples in triples_by_model.items():
            verifier_names = [n for n in self.providers if n != generator_name]
            if not verifier_names:
                logger.warning(
                    f"No verifying models available for triples generated by "
                    f"'{generator_name}' (need >=2 total providers for cross "
                    f"verification). Agreement score will default to 0.0."
                )
            for t in triples:
                flat.append((t, verifier_names))

        if not flat:
            return []

        total_calls = sum(len(v) for _, v in flat)
        logger.info(
            f"Cross-verifying {len(flat)} triple(s) across "
            f"{', '.join(self.providers)} ({total_calls} verification call(s))..."
        )

        await asyncio.gather(*(self._verify_one(t, verifier_names) for t, verifier_names in flat))

        checked = [t for t, _ in flat]
        supported_total = sum(len(t.evidence_sentences()) for t in checked)
        self.last_stats = {
            "triples_cross_verified": len(checked),
            "verification_calls_made": total_calls,
            "avg_agreement_score": (
                round(sum(t.agreement_score or 0.0 for t in checked) / len(checked), 4)
                if checked else 0.0
            ),
            "evidence_sentences_collected": supported_total,
        }
        logger.info(
            f"  Cross verification complete. Average agreement score: "
            f"{self.last_stats['avg_agreement_score']}"
        )
        return checked

    async def _verify_one(self, t: Triple, verifier_names: List[str]) -> None:
        source_text = self.chunk_lookup.get(t.source_chunk_id, "")
        triple_str = str(t)

        async def verify_with(name: str) -> Dict[str, Any]:
            provider = self.providers[name]
            try:
                raw = await provider.verify_triple_raw(source_text, triple_str)
                parsed = self._parse_verification(raw)
            except Exception as e:
                logger.warning(f"  [{name}] verification call failed for {t}: {e} (treated as NOT supported)")
                parsed = {"supported": False, "evidence": ""}

            entry = {
                "verifier": name,
                "supported": bool(parsed.get("supported", False)),
                "evidence": parsed.get("evidence", "") if self.enable_evidence_storage else "",
            }
            # Never let a NOT_SUPPORTED verdict carry evidence (Step 4:
            # "Never hallucinate evidence").
            if not entry["supported"]:
                entry["evidence"] = ""
            return entry

        results = await asyncio.gather(*(verify_with(name) for name in verifier_names))
        t.verification_results = list(results)
        t.agreement_score = (
            round(sum(1 for r in results if r["supported"]) / len(results), 4)
            if results else 0.0
        )
        t.timestamp = datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _parse_verification(raw: str) -> Dict[str, Any]:
        """
        Parse a verifier's {"supported": bool, "evidence": str} response.
        Falls back to a conservative NOT_SUPPORTED if the model returned
        something that isn't valid JSON (e.g. a stray "NO" from a smaller
        local model that ignored the JSON instruction).
        """
        raw = strip_code_fences(raw)
        try:
            data = json.loads(raw)
            return {
                "supported": bool(data.get("supported", False)),
                "evidence": str(data.get("evidence", "") or "").strip(),
            }
        except (json.JSONDecodeError, AttributeError):
            lowered = raw.strip().lower()
            if lowered.startswith("yes") or lowered.startswith("true"):
                return {"supported": True, "evidence": ""}
            return {"supported": False, "evidence": ""}
